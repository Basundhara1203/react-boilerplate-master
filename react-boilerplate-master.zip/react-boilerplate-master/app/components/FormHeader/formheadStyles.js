import  styled  from 'styled-components';
import {css} from 'styled-components';

const formheadS = css`
  
  
 
  
 background-color:#013220;
 color:white;
 margin-left:10px;
 margin-right:10px;
 height:50px;
  

 
`;

export default formheadS;

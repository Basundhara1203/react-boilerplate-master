import 'bootstrap/dist/css/bootstrap.min.css'
import {Table} from 'react-bootstrap'
import Styledformhead from './Styledformhead';
import React from 'react';
//import  './styles.css'
//import 'bootstrap/dist/css/bootstrap.min.css'
//import {Table} from 'react-bootstrap'
//import StyledHead from './StyledHead'




export const FormHead=()=>{

return(






<Styledformhead><h2><center>Employee Registration Form</center></h2></Styledformhead>

)
}
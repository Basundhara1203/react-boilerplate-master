import styled from 'styled-components';

import formheadS from './formheadStyles';

const Styledformhead = styled.div`
  ${formheadS};
`;

export default Styledformhead;

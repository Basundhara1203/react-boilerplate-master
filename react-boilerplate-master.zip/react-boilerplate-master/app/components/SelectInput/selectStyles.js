import  styled  from 'styled-components';
import {css} from 'styled-components';

const selectS = css`
  
  
 
  
  border: 1px solid orange;
  

 
`;

export default selectS;

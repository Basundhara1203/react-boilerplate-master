import styled from 'styled-components';

import selectS from './selectStyles';

const StyledSelect = styled.select`
  ${selectS};
`;

export default StyledSelect;

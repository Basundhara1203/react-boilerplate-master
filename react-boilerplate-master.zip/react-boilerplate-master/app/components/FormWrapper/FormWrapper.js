import styled from 'styled-components';

const FormWrapper = styled.div`
  width: 93%;
  
  margin-top: 30px;
  margin-bottom:30px;
  margin-left:auto;
  margin-right:auto;
  

`;

export default FormWrapper;

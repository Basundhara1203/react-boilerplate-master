import styled from 'styled-components';

import submitS from './submitStyles';

const StyledSubmit = styled.button`
  ${submitS};
`;

export default StyledSubmit;

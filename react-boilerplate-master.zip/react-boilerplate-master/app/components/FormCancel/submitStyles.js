import  styled  from 'styled-components';
import {css} from 'styled-components';

const submitS = css`
  
  
 

  margin-left:5px;
  margin-top:100px;
  margin-bottom:20px;

 
`;

export default submitS;

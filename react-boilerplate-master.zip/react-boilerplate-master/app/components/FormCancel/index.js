

import React from 'react';
//import  './styles.css'
import 'bootstrap/dist/css/bootstrap.min.css'
import {Table} from 'react-bootstrap'
import StyledSubmit from './StyledSubmit';



export const CancelButton=(props)=>{

return(

<StyledSubmit onClick={()=>props.clearData()}  className="mr-5">Cancel</StyledSubmit>



)
}

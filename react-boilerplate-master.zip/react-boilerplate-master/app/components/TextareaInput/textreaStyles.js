import  styled  from 'styled-components';
import {css} from 'styled-components';

const areaS = css`
  
  
 
  
  border: 1px solid orange;
  

 
`;

export default areaS;

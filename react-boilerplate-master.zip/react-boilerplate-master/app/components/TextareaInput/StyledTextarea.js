import styled from 'styled-components';

import areaS from './textreaStyles';

const StyledTextarea = styled.textarea`
  ${areaS};
`;

export default StyledTextarea;

import styled from 'styled-components';

const Wrapper = styled.div`
  width: 93%;
  background-color:white;
  
  margin-top: 25px;
  margin-bottom:20px;
  margin-left:auto;
  margin-right:auto;
  padding:15px;

`;

export default Wrapper;

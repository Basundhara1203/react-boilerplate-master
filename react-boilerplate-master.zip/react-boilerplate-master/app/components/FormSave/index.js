

import React from 'react';
//import  './styles.css'
import 'bootstrap/dist/css/bootstrap.min.css'
import {Table} from 'react-bootstrap'
import StyledSubmit from './StyledSubmit';



export const SubmitButton=(props)=>{

return(


<StyledSubmit onClick={()=>props.submitData(props.s_id,props.d_id)} className="mr-3">Save</StyledSubmit>


)
}

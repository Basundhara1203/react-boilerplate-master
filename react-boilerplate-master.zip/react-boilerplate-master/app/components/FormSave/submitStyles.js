import  styled  from 'styled-components';
import {css} from 'styled-components';

const submitS = css`
  
  
 

  margin-left:460px;
  margin-top:70px;
  margin-bottom:20px;

 
`;

export default submitS;

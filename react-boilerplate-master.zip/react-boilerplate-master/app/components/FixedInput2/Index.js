import React from 'react';
import {Container, Col, Row,Table } from 'react-bootstrap';
//import '../AddInput/node_modules/bootstrap/dist/css/bootstrap.css';
import 'bootstrap/dist/css/bootstrap.css';
//import '../style.css';
import {Wrapper,line} from './Wrapper'
import StyledText from './StyledText';




function TextInput(props)
{
   // console.log(props);
    let text=(
        <Table>
            <tr>
                <td style={{width:500}}>
                <label>
                        {props.form.noteName}
                </label>
                </td>
                


                <td>
                <StyledText className="input col-5" type="type"                  
                            name={props.form.noteName} defaultValue={props.form.amt}
                            onChange={(e)=>props.handleChange(e,props.i,props.j,props.r)} />
                           
                            

                        
            

                   
                </td>
                
            </tr>
        
           
            </Table>
            
    );
    return <Wrapper>{text}</Wrapper>
}

TextInput.propTypes = {
   // onChange: PropTypes.func
  // props:Proptypes.any
   
  }
  
export default TextInput;




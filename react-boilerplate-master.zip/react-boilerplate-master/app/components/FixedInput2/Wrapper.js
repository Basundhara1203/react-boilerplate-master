import styled from 'styled-components';

export const Wrapper = styled.div`
  width: 100%;
  margin-left:30px;
  margin-top: 20px;
`;


export const line = styled.div`
  
 
  border: 1px solid black;
`;


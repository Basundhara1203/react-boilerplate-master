import styled from 'styled-components';

import radioS from './radioStyles';

const StyledRadio = styled.input`
  ${radioS};
`;

export default StyledRadio;

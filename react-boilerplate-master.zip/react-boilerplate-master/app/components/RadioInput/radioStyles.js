import  styled  from 'styled-components';
import {css} from 'styled-components';

const radioS = css`
  
  
 
  
  border: 1px solid orange;
  

 
`;

export default radioS;

import styled from 'styled-components';

import dateS from './dateStyles';

const StyledDate = styled.input`
  ${dateS};
`;

export default StyledDate;

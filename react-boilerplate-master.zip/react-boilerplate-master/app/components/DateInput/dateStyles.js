import  styled  from 'styled-components';
import {css} from 'styled-components';

const dateS = css`
  
  
 
  
  border: 1px solid orange;
  

 
`;

export default dateS;

import styled from 'styled-components';

const Wrapper = styled.div`
  width: 100%;
 
  margin-top: 20px;
`;

export default Wrapper;

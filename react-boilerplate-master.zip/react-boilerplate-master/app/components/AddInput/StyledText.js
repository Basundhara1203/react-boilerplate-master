import styled from 'styled-components';

import textS from './textStyles';

const StyledText = styled.input`
  ${textS};
`;

export default StyledText;

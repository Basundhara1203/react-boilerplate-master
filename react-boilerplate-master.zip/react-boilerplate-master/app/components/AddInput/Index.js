import React from 'react';
import {Container, Col, Row } from 'react-bootstrap';
import 'bootstrap/dist/css/bootstrap.css';
//import '../style.css';
import {Wrapper,line} from './Wrapper'
import StyledText from './StyledText';




function AddInput(props)
{
   // console.log(props);
    let text=(
        <Container>
            <Row>
                <Col>
                <StyledText
                  name={props.field1}
                 placeholder={props.field1}
              //value={x.noteName}
                onChange={e => props.handleInputChange(e, props.i)}
            />
                </Col>
            


                <Col>
                <StyledText   name={props.field2}
                 placeholder={props.field2}
              //value={x.noteName}
                onChange={e => props.handleInputChange(e, props.i)} />
         
                </Col>

                <Col><button className="mr-3" onClick={props.handleAddClick}>+</button>
                    <button className="mr-5" 
                    
                    onClick={() => props.handleRemoveClick(props.i)}>-</button>
          </Col>
                
            </Row>
            </Container>
            
    );
    return <Wrapper>{text}</Wrapper>
}

  
export default AddInput;




import React from 'react';
import {Container, Col, Row } from 'react-bootstrap';
import 'bootstrap/dist/css/bootstrap.css';
//import '../style.css';
//import Wrapper from './Wrapper'
//import StyledText from './StyledText';




function TextInput2(props)
{
    console.log(props);
    return (
        <Container>
            <Row>
                <Col>
                   {props.name}
                </Col>

                <Col>
                <input className="input col-11" type="type" name={props.name}
                            id={props.id}
                            
                            onChange={props.onChange}/>
                           
                            

                        
            

                   
                </Col>
                
            </Row>
            
            </Container>
    );
  
}

TextInput2.propTypes = {
   // onChange: PropTypes.func
  // props:Proptypes.any
   
  }
  
export default TextInput2;
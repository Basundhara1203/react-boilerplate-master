import  styled  from 'styled-components';
import {css} from 'styled-components';

const columnS = css`
  
  

  
 width:490px;
  

 
`;

export default columnS;

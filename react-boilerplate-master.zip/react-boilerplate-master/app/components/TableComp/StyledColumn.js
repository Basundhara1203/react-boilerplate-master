import styled from 'styled-components';

import columnS from './columnStyles';

const StyledColumn = styled.td`
  ${columnS};
`;

export default StyledColumn;

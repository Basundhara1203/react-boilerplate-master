import React from 'react';
//import  './styles.css'
import 'bootstrap/dist/css/bootstrap.min.css'
import {Table} from 'react-bootstrap'
import StyledColumn from './StyledColumn'
import Wrapper from './Wrapper'



const TableComp = (props) => {
  return (
  <div className="t">

    <Table  striped bordered hover >
  
    
 
      <tr>

     
        <StyledColumn>{props.data.id}</StyledColumn>
        <StyledColumn>{props.data.employeeName}</StyledColumn>
        <StyledColumn>{props.data.employeeDepartment}</StyledColumn>
        <StyledColumn><button className="btn btn-success mr-3" onClick={() =>props.edit(props.data.id)}>Details</button> </StyledColumn>
                    
        <StyledColumn>  <button className="btn btn-warning mr-3" onClick={() =>props.editDetails(props.data)}>Edit</button> </StyledColumn>
        <StyledColumn><button className="btn btn-danger mr-3" onClick={() => props.deleteEmployee(props.data.id)}>Delete</button></StyledColumn>
                   
    </tr>

     
 </Table></div>
  )
}
export default  TableComp;
import styled from 'styled-components';

const AccordionWrapper = styled.div`
  
  
  
  

`;

export default AccordionWrapper;

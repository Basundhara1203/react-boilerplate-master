import styled from 'styled-components';

const Wrapper = styled.div`
  width: 80%;
  border:  3px solid blue;
  margin-top: 30px;
  margin-bottom:30px;
  margin-left:auto;
  margin-right:auto;
  padding:30px;

`;

export default Wrapper;

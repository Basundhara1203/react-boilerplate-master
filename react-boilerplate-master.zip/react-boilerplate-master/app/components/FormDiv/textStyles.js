import  styled  from 'styled-components';
import {css} from 'styled-components';

const textS = css`
  
  
 
  
  border: 1px solid orange;
  margin-top:10px;
  margin-bottom:10px;
 
`;

export default textS;

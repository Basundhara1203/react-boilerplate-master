import React from 'react';
import {Container, Col, Row } from 'react-bootstrap';
import 'bootstrap/dist/css/bootstrap.css';
//import '../style.css';
import Wrapper from './Wrapper'
import StyledText from './StyledText';




function TextInput(props)
{
   // console.log(props);
    let text=(
        <Container>
          
                <Row>
                    <Col>
                    Employee Name :
                    </Col>
                    <Col>
                    <StyledText  onChange={(e)=>props.handleChange(e)}  name="employeeName" value={props.state.employeeName} type="text" placeholder="Employee Name" />  
                    </Col>
                </Row>

                <Row>
                    <Col>
                    Employee Department :
                    </Col>
                    <Col>
                    <StyledText onChange={(e)=>props.handleChange(e)}  name="employeeDepartment" value={props.state.employeeDepartment} type="text" placeholder="Employee Department" />
                    </Col>
                </Row>
             <Row>
                 <Col></Col>
                 <Col>
                 {props.state.id ? <button className="btn btn-warning mr-3" onClick={props.submitData}>Update</button> : <button className="btn btn-success mr-3" onClick={props.submitData}>Add</button>}    
                 </Col>
             </Row>

            
            
      
                        
            

                   
               
            </Container>
    );
    return <Wrapper>{text}</Wrapper>
}

TextInput.propTypes = {
   // onChange: PropTypes.func
  // props:Proptypes.any
   
  }
  
export default TextInput;
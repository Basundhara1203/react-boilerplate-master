import  styled  from 'styled-components';
import {css} from 'styled-components';

const headS = css`
  
  

  width:490px;
 background-color:#9400D3;
 color:white;
  

 
`;

export default headS;

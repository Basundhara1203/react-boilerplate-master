import styled from 'styled-components';

import headS from './headStyles';

const StyledHead = styled.th`
  ${headS};
`;

export default StyledHead;

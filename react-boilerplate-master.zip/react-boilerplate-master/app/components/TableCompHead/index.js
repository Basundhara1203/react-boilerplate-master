import React from 'react';
//import  './styles.css'
import 'bootstrap/dist/css/bootstrap.min.css'
import {Table} from 'react-bootstrap'
import StyledHead from './StyledHead'






export   const Head=()=>{
    return(
        <div className="t">
        <Table  striped bordered hover>
        <tbody>
            <StyledHead>
                Employee Id
            </StyledHead>
            <StyledHead>
                Employee Name
            </StyledHead>
          
            
            <StyledHead>
                Depatment Name
            </StyledHead>
           
           
            <StyledHead>
                 Details Action
            </StyledHead>

            <StyledHead>
                 Edit Action
            </StyledHead>

            <StyledHead>
                Delete Action
            </StyledHead>



         
        </tbody>
        
        </Table>
        </div>
    )
  }
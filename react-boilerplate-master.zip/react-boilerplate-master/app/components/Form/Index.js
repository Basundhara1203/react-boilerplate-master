import styled from 'styled-components';

const Form = styled.div`
  

   margin-left:10px;
    margin-right:10px ;
    margin-top:10px ;
    border: 8px solid blue;
`;

export default Form;

import React from 'react';
//import  './styles.css'
import 'bootstrap/dist/css/bootstrap.min.css'
import {Table} from 'react-bootstrap'
import StyledColumn from './StyledColumn'



const TableComponent = (props) => {
  return (
  <div className="t">

    <Table  striped bordered hover >
  
    
    <tbody>
      <tr>
      
     <StyledColumn>{props.user.id}</StyledColumn>
        <StyledColumn className="f">{props.user.employee_name}</StyledColumn>
        <StyledColumn className="f">{props.user.employee_salary}</StyledColumn>
        <StyledColumn className="f">{props.user.employee_age}</StyledColumn>
       


     
      </tr>
      </tbody>
    </Table>
    </div>
  )
}
export default  TableComponent;
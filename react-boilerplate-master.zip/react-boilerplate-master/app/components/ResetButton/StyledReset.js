import styled from 'styled-components';

import resetS from './resetStyles';

const StyledReset = styled.button`
  ${resetS};
`;

export default StyledReset;

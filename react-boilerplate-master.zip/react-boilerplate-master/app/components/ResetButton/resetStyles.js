import  styled  from 'styled-components';
import {css} from 'styled-components';

const resetS = css`
  
  
 
  
  
  margin-top:10px;
  margin-bottom:20px;

 
`;

export default resetS;

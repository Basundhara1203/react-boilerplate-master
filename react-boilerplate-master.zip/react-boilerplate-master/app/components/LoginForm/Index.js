import React from 'react';
import {Container, Col, Row } from 'react-bootstrap';
import 'bootstrap/dist/css/bootstrap.css';
//import '../style.css';
import Wrapper from './Wrapper'
import StyledText from './StyledText';




function TextInput(props)
{
   // console.log(props);
    let text=(
        <Container>
          
                <Row>
                    <Col>
                    UserName :
                    </Col>
                    <Col>
                    <StyledText  onChange={(e)=>props.handleChange(e)}  name="username" value={props.state.username} type="text" placeholder="username" /> 
                    </Col>
                </Row>

                <Row>
                    <Col>
                    Password : 
                    </Col>
                    <Col>
                    <StyledText onChange={(e)=>props.handleChange(e)}  name="password" value={props.state.password} type="password" placeholder="password" />
                    </Col>
                </Row>
             <Row>
                 <Col></Col>
                 <Col>
                     <button className="btn btn-success mr-3" style={{marginTop:30}}onClick={props.login}>Login</button>  
                 </Col>
                 <Col></Col>
             </Row>               
               
            </Container>
    );
    return <Wrapper>{text}</Wrapper>
}

TextInput.propTypes = {
   // onChange: PropTypes.func
  // props:Proptypes.any
   
  }
  
export default TextInput;
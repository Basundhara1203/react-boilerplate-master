import React from 'react';
import {Container, Col, Row,Table } from 'react-bootstrap';
//import '../AddInput/node_modules/bootstrap/dist/css/bootstrap.css';
import 'bootstrap/dist/css/bootstrap.css';
//import '../style.css';
import {Wrapper,line} from './Wrapper'
import StyledText from './StyledText';




function Calculation(props)
{
   // console.log(props);
    let text=(
        <Table>   
            <tr>
                <td style={{width:550}}>
                   {props.fieldname}
                </td>
                <td>
                {props.calculate()}
                </td>
            </tr>
            </Table>
            
    );
    return <Wrapper>{text}</Wrapper>
}


  
export default Calculation;




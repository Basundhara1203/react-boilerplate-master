import styled from 'styled-components';

export const Wrapper = styled.div`
  height:28px;
  width: 93%;
  margin-left:30px;
  margin-top: 10px;
  
`;


export const line = styled.div`
  
 
  border: 1px solid black;
`;


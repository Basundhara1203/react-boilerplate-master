/*
 *
 * Net reducer
 *
 */
import produce from 'immer';
import { DEFAULT_ACTION } from './constants';

export const initialState = {data:[
  {id :"1011", noteName: "Cash",amt:"0"},
  {id :"1012", noteName: "Chequing and Savins Account",amt:"0"},
  {id :"1013", noteName: "Non-Registered Investments",amt:"0"}]
};

/* eslint-disable default-case, no-param-reassign */
const netReducer = (state = initialState, action) =>
  produce(state, (/* draft */) => {
    switch (action.type) {
      case DEFAULT_ACTION:
        break;
    
    case 'ONCHANGE_ACTION':
      console.log(state.data)
      console.log(action)

      return {    
       ...state,
      
       ...(state.data[action.index].amt=action.value)}
      /*
       data:[
         ...(state.data.map((d,i)=>
         i===action.index?{
           ...d,amt:action.value}:d))]
         }*/
       
      // state.data[action.i].amt:action.value
       
      case 'CLICK':
        console.log("okokokok")
        alert(JSON.stringify(state))
        return{

        }
    }
  
  });
    


export default netReducer;

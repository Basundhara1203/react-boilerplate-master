/**
 *
 * Asynchronously loads the component for Net
 *
 */

import loadable from 'utils/loadable';

export default loadable(() => import('./index'));

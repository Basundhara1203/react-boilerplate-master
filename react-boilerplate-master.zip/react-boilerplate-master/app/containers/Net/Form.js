import React, { memo } from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { Helmet } from 'react-helmet';
import { FormattedMessage } from 'react-intl';
import { createStructuredSelector } from 'reselect';
import { compose } from 'redux';

import { useInjectSaga } from 'utils/injectSaga';
import { useInjectReducer } from 'utils/injectReducer';
import makeSelectNet from './selectors';
import reducer from './reducer';
import saga from './saga';
import messages from './messages';

export function Form(props) {

 return(

<div>
 {props.net.data.map((field,i)=>{
    return(
    <div>
    {console.log(field.noteName,i)}
    
    <h1>gfv</h1>
     <label>{field.noteName}</label>
     

     <input id={i} name={field.noteName}  type="text" onChange={(e)=>props.handleChange(e)}/>
    

</div>
  ) })}




</div>
 )





}

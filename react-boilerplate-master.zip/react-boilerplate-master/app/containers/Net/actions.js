/*
 *
 * Net actions
 *
 */

import { DEFAULT_ACTION } from './constants';

export function defaultAction() {
  return {
    type: DEFAULT_ACTION,
  };
}
export function handleChange(e,i) {
  return {
    type:"ONCHANGE_ACTION",
    name:e.target.name,
    value:e.target.value,
    index:e.target.id

  };
}
export function click() {
  return {
    type:"CLICK",
   
  };
}

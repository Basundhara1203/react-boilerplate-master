/**
 *
 * Net
 *
 */

import React, { memo } from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { Helmet } from 'react-helmet';
import { FormattedMessage } from 'react-intl';
import { createStructuredSelector } from 'reselect';
import { compose } from 'redux';
import { handleChange ,click} from './actions';
import {Form} from './Form'

import { useInjectSaga } from 'utils/injectSaga';
import { useInjectReducer } from 'utils/injectReducer';
import makeSelectNet from './selectors';
import reducer from './reducer';
import saga from './saga';
import messages from './messages';

export function Net(props) {
  useInjectReducer({ key: 'net', reducer });
  useInjectSaga({ key: 'net', saga });

  const handleInputChange = (e, index) => {
    console.log("index",index);
   
    const { name, value } = e.target;
   // const list = [...inputList];
   
    list[index][name] = value;
    setInputList(list);
  };

  return (
    <div>
      <Helmet>
        <title>Net</title>
        <meta name="description" content="Description of Net" />
      </Helmet>
      <FormattedMessage {...messages.header} />
     
      <div>
     
      <Form net={props.net} handleChange={props.handleChange}/>
      <button  onClick={props.click}>click</button>
      {JSON.stringify(props.net)}
     </div>
    </div>

  


  );
}

Net.propTypes = {
  dispatch: PropTypes.func.isRequired,
};

const mapStateToProps = createStructuredSelector({
  net: makeSelectNet(),
});

function mapDispatchToProps(dispatch) {
  return {
    dispatch,
    handleChange:(e,i)=>{dispatch(handleChange(e,i))},
    click:()=>{dispatch(click())}
  };
}

const withConnect = connect(
  mapStateToProps,
  mapDispatchToProps,
);

export default compose(
  withConnect,
  memo,
)(Net);

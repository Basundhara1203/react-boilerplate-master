// import { selectNetDomain } from '../selectors';

describe('selectNetDomain', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(false);
  });
});

import { createSelector } from 'reselect';
import { initialState } from './reducer';

/**
 * Direct selector to the net state domain
 */

const selectNetDomain = state => state.net || initialState;

/**
 * Other specific selectors
 */

/**
 * Default selector used by Net
 */

const makeSelectNet = () =>
  createSelector(
    selectNetDomain,
    substate => substate,
  );

export default makeSelectNet;
export { selectNetDomain };

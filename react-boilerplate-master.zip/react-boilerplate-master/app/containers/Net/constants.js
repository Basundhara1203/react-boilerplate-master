/*
 *
 * Net constants
 *
 */

export const DEFAULT_ACTION = 'app/Net/DEFAULT_ACTION';

/**
 *
 * Crudapplication
 *
 */
//import React, { memo } from 'react';
import {Container, Col, Row } from 'react-bootstrap';
//import PropTypes from 'prop-types';
//import { connect } from 'react-redux';
//import { Helmet } from 'react-helmet';
//import { FormattedMessage } from 'react-intl';
//import { createStructuredSelector } from 'reselect';
//import { compose } from 'redux';
import {actionsub,actionset,actionreset} from './actions'
//import TextInput from './component/TextInput';
import DateInput from '../../components/DateInput/Index';
import SelectInput from '../../components/SelectInput/Index';
import RadioInput from '../../components/RadioInput/Index';
import TextareaInput from '../../components/TextareaInput/Index';
import {FormHead } from '../../components/FormHeader/index';


//import './style.css';


//import { useInjectReducer } from 'utils/injectReducer';
//import makeSelectRegistration from './selectors';
//import reducer from './reducer';
//import messages from './messages';
import SignInFormDesign from './SignInFormDesign';
import React, { memo ,useState} from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { Helmet } from 'react-helmet';
import { FormattedMessage } from 'react-intl';
import { createStructuredSelector } from 'reselect';
import { compose } from 'redux';
import  { useEffect } from 'react';
import {getEmployee,addEmployee, editEmployee, deleteEmployee} from './actions';
import { useSelector, useDispatch } from 'react-redux';

import { useInjectReducer } from 'utils/injectReducer';
import makeSelectCrudapplication from './selectors';
  //makeSelectCrudapperrorapplication} from './selectors';
import reducer from './reducer';
import messages from './messages';

export function Crudapplication(
  
 props
  ) {
    const [state, setState] = useState({id:0, employeeName:"", employeeDepartment:"" });
    const handleChange=(e)=>{
      const {name,value}= e.target;
      setState(preState=>({
        ...preState,
        [name]:value
      }));
    };
  useInjectReducer({ key: 'crudapplication', reducer });
 

  const dispatch = useDispatch();

    //const {userss} = useSelector(state =>state.users);

   

    //const isloading = useSelector(state => state.isloading);

    //const error = useSelector(state => state.error);
  
    useEffect(() => {
      dispatch(getEmployee());
      
    }, [])
    /*const [id, setid] = useState(0);
    const [employeeName, setEmployeeName] = useState("");
    const [employeeDepartment, setEmployeeDepartment] = useState("");
    */


 const submitData = () => {  
    if (state.employeeName && state.employeeDepartment && !state.id) {  
      const newEmployee = {  
        id: Math.floor(Math.random() * (999 - 100 + 1) + 100),  
        employeeName: state.employeeName,  
        employeeDepartment: state.employeeDepartment,  
      };  
  
      props.addEmployee(newEmployee);  
    } else if (state.employeeName && state.employeeDepartment && state.id) {  
      const updatedDetails = {  
        id: state.id,  
        employeeName: state.employeeName,  
        employeeDepartment: state.employeeDepartment,  
      };  
  
      props.editEmployee(updatedDetails);  
    } else {  
      alert('Enter Employee Details.');  
    }  
  
   clearData();  
  }  
  
 const editDetails = (data) => {  
    setState({  
      id: data.id,  
      employeeName: data.employeeName,  
      employeeDepartment: data.employeeDepartment  
    })  
  }  
  
 const deleteEmployee = (id) => {  
    clearData();  
    if (window.confirm("Are you sure?")) {  
      props.deleteEmployee(id);  
    }  
  }  
  /*
  handleNameChange = (e) => {  
    this.setState({  
      employeeName: e.target.value  
    });  
  }  
  
  handleDepartmentChange = (e) => {  
    this.setState({  
      employeeDepartment: e.target.value  
    });  
  }  
  */
const  clearData = () => {  
   setState({  
      id: 0,  
      employeeName: "",  
      employeeDepartment: ""  
    });  
  }  
  
  return (
       <div className="App">  
        <header className="App-header">  
           
          <h1 className="App-title">CRUD opeartions for Employee Module</h1>  
        </header>  
        <p className="App-intro">  
          <div className="leftsection">  
          Employee id : <input onChange={(e)=>handleChange(e)} name="id" value={state.id} type="text" placeholder="Employee id" /> <br />  
            Employee Name : <input onChange={(e)=>handleChange(e)}  name="employeeName" value={state.employeeName} type="text" placeholder="Employee Name" /> <br />  
            Employee Department :  <input onChange={(e)=>handleChange(e)}  name="employeeDepartment" value={state.employeeDepartment} type="text" placeholder="Employee Department" /><br />  
            {state.id ? <button onClick={submitData}>UPDATE</button> : <button onClick={submitData}>ADD</button>}   <button onClick={clearData}>CLEAR</button>  
          </div> 
          </p>
    //console.log(props.employees.employees),
      <div>
            <table>  
              <thead>  
                <tr>  
                  <th>ID</th>  
                  <th>Name</th>  
                  <th>Depatment Name</th>  
                  <th>Action(s)</th>  
                </tr>  
              </thead>  
              <tbody>  
              {props && props.employees && props.employees.employees.map((data, index) => {  
                  return <tr key={(index + 1)}>  
                    <td>{(index + 1)}</td>  
                    <td>{data.employeeName}</td>  
                    <td>{data.employeeDepartment}</td>  
                 

                    <td><button onClick={() =>editDetails(data)}>EDIT</button> <button onClick={() => deleteEmployee(data.id)}>DELETE</button> </td> 
                  </tr>  
                })}  
              
              </tbody>  
            </table>  
         </div>
         </div>

    );  
 
  

  

  
}

Crudapplication.propTypes = {
 // dispatch: PropTypes.func.isRequired,
 getEmployee:PropTypes.any,
 employees: PropTypes.any,  
 addEmployee: PropTypes.func,  
    editEmployee: PropTypes.func,  
    deleteEmployee: PropTypes.func ,
    clearData:PropTypes.func
   // getEmployee: PropTypes.func.isRequired  
 // ErrorSet:PropTypes.any
};

const mapStateToProps = createStructuredSelector({
  employees: makeSelectCrudapplication(),
 //error: makeSelectCrudapperrorapplication()
});

function mapDispatchToProps(dispatch) {
  return {
    dispatch,
    getEmployee:()=>{dispatch(getEmployee)},
    addEmployee:(data)=>{dispatch(addEmployee(data))},
   editEmployee:(data)=>{dispatch(editEmployee(data))},
  deleteEmployee:(id)=>{dispatch(deleteEmployee(id))},
   
  };
}

const withConnect = connect(
  mapStateToProps,
 mapDispatchToProps,
);

export default compose(
  withConnect,
  memo,
)(Crudapplication);

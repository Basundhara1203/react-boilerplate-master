import React, { Component } from "react";
//import './style.css'
import {Container, Col, Row } from 'react-bootstrap';
import 'bootstrap/dist/css/bootstrap.css'
import TextInput from 'components/TextInput/Index';
import TextInput2 from 'components/TextInput2/index';
import { connect } from "react-redux";
//import { formValues } from "redux-form";
//import TextInput from './component/TextInput';
import Form from '../../components/Form/Index';
import DateInput from '../../components/DateInput/Index';
import SelectInput from '../../components/SelectInput/Index';
import RadioInput from '../../components/RadioInput/Index';
import TextareaInput from '../../components/TextareaInput/Index';
import {SubmitButton } from '../../components/SubmitButton/index';
import {ResetButton } from '../../components/ResetButton/index';
import {FormHead } from '../../components/FormHeader/index';




export default function SignInFormDesign(props) { 
  console.log()
    return(
      <div>
      <FormHead/>
    
        <Form>
        
        <form onSubmit={props.submitForm}>
        <fieldset className="set">
         <legend>Enter Details</legend>
            <div className="input-group">
             
              <TextInput2
               
                name="EmployeeId"
                id="EmployeeId"
                //={props.state.EmployeeId}
                //ErrorSet={props.ErrorSet}
                onChange={props.handleInputChange}
               
              />
            </div>
            <Row>
            <Col></Col>
            
                </Row>
                
            <div>
            <div className="input-group">
              
              <TextInput2
                name="EmployeeName"
                id="EmployeeName"
                //ErrorSet={props.ErrorSet}
                //value={props.state.EmployeeName}
                onChange={props.handleInputChange}
               
              />
    
            </div>
            <Row>
            <Col></Col>
            
                </Row>
            
            </div>

  
           
           <SubmitButton/>
           <ResetButton onReset={props.onReset}/>
          

         
           
            
            </fieldset>
          </form>
          <div className="message">
            
          </div>
        </Form>
        </div>

    );
}
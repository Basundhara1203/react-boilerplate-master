// import { selectCrudapplicationDomain } from '../selectors';

describe('selectCrudapplicationDomain', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(false);
  });
});

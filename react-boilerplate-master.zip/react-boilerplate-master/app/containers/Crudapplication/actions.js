/*import { DEFAULT_ACTION,SET_FORMVALUES,SUBMIT_FORM,onReset } from './constants';

export function defaultAction() {
  return {
    type: DEFAULT_ACTION,
  };
};
export const actionset =(e)=>{
  return{
      type:SET_FORMVALUES,
      value:e.target.value,
      name:e.target.name,
      //ErrorSet:ErrorSet,
     

      event:e
 
  }
};
export const actionsub =(e)=>{
  return{
      type:SUBMIT_FORM,
      value:e.target.value,
      name:e.target.name,
      event:e,
      //ErrorSet:ErrorSet,
      //isValid:isValid,
 
  }
 };
 export const actionreset =(e)=>{
  return{
      type:onReset,
      value:e.target.value,
      name:e.target.name,
      event:e
 
  }
};*/

export function getEmployee() {  
  return dispatch => {  
      return dispatch({  
          type: 'GET_EMPLOYEE'  
      });  
  }  
}; 
export function addEmployee(data) {  
  return dispatch => {  
      return dispatch({  
          type: 'ADD_EMPLOYEE',  
          payload: data  
      });  
  }  
};  

export function editEmployee(data) {  
  return dispatch => {  
      return dispatch({  
          type: 'EDIT_EMPLOYEE',  
          payload: data  
      });  
  }  
};  

export function deleteEmployee(employeeId) {  
  return dispatch => {  
      return dispatch({  
          type: 'DELETE_EMPLOYEE',  
          payload: employeeId  
      });  
  }  
}; 
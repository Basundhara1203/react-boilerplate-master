import { createSelector } from 'reselect';
import { initialState } from './reducer';

/**
 * Direct selector to the crudapplication state domain
 */

const selectCrudapplicationDomain = state =>
  state.crudapplication || initialState;

/**
 * Other specific selectors
 */

/**
 * Default selector used by Crudapplication
 */

const makeSelectCrudapplication = () =>
  createSelector(
    selectCrudapplicationDomain,
    substate => substate,
  );
  
const makeSelectCrudapperrorlication = () =>
createSelector(
  selectCrudapplicationDomain,
  substate => substate.ErrorSet,
);

export default makeSelectCrudapplication;
export { selectCrudapplicationDomain };

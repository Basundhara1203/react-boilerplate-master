/**
 *
 * Asynchronously loads the component for Crudapplication
 *
 */

import loadable from 'utils/loadable';

export default loadable(() => import('./index'));

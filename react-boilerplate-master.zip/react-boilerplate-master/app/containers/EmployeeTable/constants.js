/*
 *
 * EmployeeTable constants
 *
 */

export const DEFAULT_ACTION = 'app/EmployeeTable/DEFAULT_ACTION';

export const GET_EMPLOYEES_REQUESTED = 'GET_EMPLOYEES_REQUESTED';
export const GET_EMPLOYEES_SUCCESS = 'GET_EMPLOYEES_SUCCESS';
export const GET_EMPLOYEES_FAILED = 'GET_EMPLOYEES_FAILED';
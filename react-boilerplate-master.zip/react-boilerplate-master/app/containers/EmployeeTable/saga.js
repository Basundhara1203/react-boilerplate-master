// import { take, call, put, select } from 'redux-saga/effects';

import { call, put, takeEvery } from 'redux-saga/effects'
import axios from 'axios'
// Individual exports for testing
import { all } from 'redux-saga/effects'
import request from 'utils/request';
import {
   getUsersFailed,getUsersSuccess,getUsers
} from './actions'










function* fetchEmployees(action) {
   const requestURL="http://dummy.restapiexample.com/api/v1/employees"
  try {
      const employees =  yield call(request,requestURL);
         //axios.get, "http://dummy.restapiexample.com/api/v1/employees");
      
      
      const users=employees.data;
      
      console.log("inusersaga",users)
      console.log("in users saga ...rs",employees)



      //yield put({type: 'GET_EMPLOYEES_SUCCESS', users: users});
      yield put(getUsersSuccess(users) );

      //console.log("inusersaga2"+data)

   } catch (e) {
      //yield put({type: 'GET_EMPLOYEES_FAILED', message: e.message});
      yield put(getUsersFailed(e));
   }
}









function* requestSaga() {
  // yield takeEvery('GET_EMPLOYEES_REQUESTED', fetchEmployees);
  yield takeEvery(getUsers, fetchEmployees);
}

//export default requestSaga;

export default function* employeeTableSaga() {
  // See example in containers/HomePage/saga.js
 
  
    yield all([
      requestSaga(),
    ])
  
  
}
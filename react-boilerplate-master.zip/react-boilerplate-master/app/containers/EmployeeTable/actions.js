/*
 *
 * EmployeeTable actions
 *
 */

import * as type from './constants';


export function getUsers() {
  return {

    
      // event:e,
       type: type.GET_EMPLOYEES_REQUESTED,
  }
}


export function getUsersFailed(e) {
  return {


         type: type.GET_EMPLOYEES_FAILED,
         message: e.message

  }
}


export function getUsersSuccess(users) {
  return {


    type: type.GET_EMPLOYEES_SUCCESS,
    users:users

  }
}


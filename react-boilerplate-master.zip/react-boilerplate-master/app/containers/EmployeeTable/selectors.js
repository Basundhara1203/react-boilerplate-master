import { createSelector } from 'reselect';
import { initialState } from './reducer';

/**
 * Direct selector to the employeeTable state domain
 */

const selectEmployeeTableDomain = state => state.employeeTable || initialState;

/**
 * Other specific selectors
 */
/*
const selectEmployees = (state) => state.get('users');


const makeSelectEmployees = () => createSelector(
  selectEmployees,
  employeesState=>employeesState.get('users'));

  const makeSelectLoad = () => createSelector(
    selectEmployees,
    employeesState=>employeesState.get('isLoading'));
  
const makeSelectError = () => createSelector(
  selectEmployees,
  employeesState=>employeesState.get('error'));

/**
 * Default selector used by EmployeeTable
 */

const makeSelectEmployeeTable = () =>
  createSelector(
    selectEmployeeTableDomain,
    substate => substate
  );

  const makeSelectusers = () =>
  createSelector(
    selectEmployeeTableDomain,
    substate => substate.get('users')
  );

  const makeSelectloading = () =>
  createSelector(
    selectEmployeeTableDomain,
    substate => substate.get('isLoading')
  );
  
  const makeSelecterror = () =>
  createSelector(
    selectEmployeeTableDomain,
    substate => substate.get('error')
  );



export default makeSelectEmployeeTable;
export { selectEmployeeTableDomain ,
  makeSelectusers,
  makeSelecterror,
  makeSelectloading

};


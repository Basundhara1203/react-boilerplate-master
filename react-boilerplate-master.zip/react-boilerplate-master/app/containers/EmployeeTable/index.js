/**
 *
 * EmployeeTable
 *
 */

import  { memo } from 'react';
import PropTypes from 'prop-types';
import React, { useEffect } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { getUsers } from './actions';

//import 'bootstrap/dist/css/bootstrap.min.css'
import {Table} from 'react-bootstrap'
//import  './styles.css'
//import TableComponent from './TableComponent.js';
import TableComponent from '../../components/TableComponent/Index';
import {Head} from '../../components/TableHead/index';
import { connect } from 'react-redux';
import { Helmet } from 'react-helmet';
import { FormattedMessage } from 'react-intl';
import { createStructuredSelector } from 'reselect';
import { compose } from 'redux';

import { useInjectSaga } from 'utils/injectSaga';
import { useInjectReducer } from 'utils/injectReducer';
import makeSelectEmployeeTable from './selectors';
import makeSelectusers from './selectors';

import reducer from './reducer';
import saga from './saga';
import messages from './messages';


export function EmployeeTable(props,state
  ) {
  useInjectReducer({ key: 'employeeTable', reducer });
  useInjectSaga({ key: 'employeeTable', saga });


  
    const dispatch = useDispatch();

    //const {userss} = useSelector(state =>state.users);

   

    //const isloading = useSelector(state => state.isloading);

    //const error = useSelector(state => state.error);
  
    useEffect(() => {
      dispatch(getUsers());
      
    }, [])
    
  // if(props.employeeTable.users.users===[]){
    return (
      //console.log(userss),
      console.log("yooo",props.employeeTable.users.users),
      <>

       <Head/>
      {props.employeeTable && props.employeeTable.users && props.employeeTable.users.users && props.employeeTable.users.users.map((user) => (
      
 
 
 
 
 
 
 
 <TableComponent key={user.id} user={user} />
      ))}
        
    

        
      </>
    )
           
  
}

EmployeeTable.propTypes = {
  dispatch: PropTypes.func,
 // userss:PropTypes.object,
 // employeeTable:PropTypes.func,

  //submit:PropTypes.func,


};
/*
const mapStateToProps = (state) => ({
   state:state,
});
*/
const mapStateToProps = createStructuredSelector({
  employeeTable: makeSelectEmployeeTable(),
  //userss:makeSelectusers(),
})

/*
function mapDispatchToProps(dispatch) {
  return {
    //dispatch,
    submit:()=>{dispatch(getUsers())},
   // dispatch_log_to_console_function: () => dispatch(log_to_console_function()
    
  };
}
*/
const withConnect = connect(
  mapStateToProps,
  //mapDispatchToProps,
  null
);

export default compose(
  withConnect,
  memo,
)(EmployeeTable);

//export default EmployeeTable;
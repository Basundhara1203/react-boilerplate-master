/**
 * Test sagas
 */

/* eslint-disable redux-saga/yield-effects */
// import { take, call, put, select } from 'redux-saga/effects';
// import employeeTableSaga from '../saga';

// const generator = employeeTableSaga();

describe('employeeTableSaga Saga', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(false);
  });
});

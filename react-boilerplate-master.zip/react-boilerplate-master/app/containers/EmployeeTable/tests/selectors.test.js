// import { selectEmployeeTableDomain } from '../selectors';

describe('selectEmployeeTableDomain', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(false);
  });
});

/*
 *
 * EmployeeTable reducer
 *
 */
import produce from 'immer';
import * as type from './constants';
import { combineReducers } from 'redux';



export const initialState =({
  users: [],
  isloading: false,
  error: null,
});

/* eslint-disable default-case, no-param-reassign */
export  function  users(state = initialState, action) {
    switch (action.type) {
     
        case type.GET_EMPLOYEES_REQUESTED:
        
          return {
            ...state,
            isloading: true,
           
          }
        case type.GET_EMPLOYEES_SUCCESS:
            console.log("reducer",action.users)
         return {
            ...state,
            isloading: false,
            users: action.users,
            
            
          }
        
        case type.GET_EMPLOYEES_FAILED:
          return {
            ...state,
            isloading: false,
            error: action.message,
          }
        default:
          return state
    }
  };
  const employeeTableReducer = combineReducers({
   users: users,});

export default employeeTableReducer;



  
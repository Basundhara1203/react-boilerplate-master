/*
 *
 * NetBalance constants
 *
 */

export const DEFAULT_ACTION = 'app/NetBalance/DEFAULT_ACTION';

/*
 * NetBalance Messages
 *
 * This contains all the text for the NetBalance container.
 */

import { defineMessages } from 'react-intl';

export const scope = 'app.containers.NetBalance';

export default defineMessages({
  header: {
    id: `${scope}.header`,
    defaultMessage: 'This is the NetBalance container!',
  },
});

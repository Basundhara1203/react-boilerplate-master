/**
 *
 * Asynchronously loads the component for NetBalance
 *
 */

import loadable from 'utils/loadable';

export default loadable(() => import('./index'));

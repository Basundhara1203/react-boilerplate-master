import React, { Component } from "react";
//import './style.css'
import {Container, Col, Row } from 'react-bootstrap';
import 'bootstrap/dist/css/bootstrap.css'
import TextInput from 'components/TextInput/Index';
import { connect } from "react-redux";
//import { formValues } from "redux-form";
//import TextInput from './component/TextInput';





export default function Form(props) {

return(
    <div>
   
   <div id="example-collapse-text">
  
       {props.inputList.map((x, i) => {
        return (
          <div className="box">
        
            <input
              name="noteName"
              placeholder="Enter First Name"
              value={x.noteName}
              onChange={e => props.handleInputChange(e, i)}
            />
            <input
              className="ml10"
              name="amt"
              placeholder="Enter Last Name"
              value={x.amt}
              onChange={e => props.handleInputChange(e, i)}
            />
            <div className="btn-box">
             
              
          
             
            </div>
          </div>
        );
      })}
        </div> 
   
  </div> 
)

 }


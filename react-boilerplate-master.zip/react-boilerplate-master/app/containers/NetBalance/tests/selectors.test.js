// import { selectNetBalanceDomain } from '../selectors';

describe('selectNetBalanceDomain', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(false);
  });
});

import { createSelector } from 'reselect';
import { initialState } from './reducer';

/**
 * Direct selector to the netBalance state domain
 */

const selectNetBalanceDomain = state => state.netBalance || initialState;

/**
 * Other specific selectors
 */

/**
 * Default selector used by NetBalance
 */

const makeSelectNetBalance = () =>
  createSelector(
    selectNetBalanceDomain,
    substate => substate,
  );

export default makeSelectNetBalance;
export { selectNetBalanceDomain };

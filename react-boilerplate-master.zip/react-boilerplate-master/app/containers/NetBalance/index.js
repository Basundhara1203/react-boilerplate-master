/**
 *
 * NetBalance
 *
 */

import React, { memo } from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { Helmet } from 'react-helmet';
import { FormattedMessage } from 'react-intl';
import { createStructuredSelector } from 'reselect';
import { compose } from 'redux';
import Accordion from 'react-bootstrap/Accordion'
import Card from 'react-bootstrap/Card'
//import '../../components/AddInput/node_modules/bootstrap/dist/css/bootstrap.css';
import 'bootstrap/dist/css/bootstrap.css';

import { useInjectSaga } from 'utils/injectSaga';
import { useInjectReducer } from 'utils/injectReducer';
import makeSelectNetBalance from './selectors';
import reducer from './reducer';
import saga from './saga';
import messages from './messages';
import FixedForm from './FixedForm';

export function NetBalance() {
 
  useInjectReducer({ key: 'example', reducer });
  useInjectSaga({ key: 'example', saga });





  return (
    <div>
      <Helmet>
        <title>NetBalance</title>
        <meta name="description" content="Description of NetBalance" />
      </Helmet>
      <FormattedMessage {...messages.header} />
     
 <Accordion defaultActiveKey="0">
  <Card>
    <Accordion.Toggle as={Card.Header} eventKey="0">
      Click me!
    </Accordion.Toggle>
    <Accordion.Collapse eventKey="0">
      <Card.Body>Hello! I'm the body</Card.Body>
    </Accordion.Collapse>
  </Card>
  <Card>
    <Accordion.Toggle as={Card.Header} eventKey="1">
      Click me!
    </Accordion.Toggle>
    <Accordion.Collapse eventKey="1">
      <Card.Body>Hello! I'm another body</Card.Body>
    </Accordion.Collapse>
  </Card>
</Accordion>

    </div>
  );
}

NetBalance.propTypes = {
  dispatch: PropTypes.func.isRequired,
};

const mapStateToProps = createStructuredSelector({
  netBalance: makeSelectNetBalance(),
});

function mapDispatchToProps(dispatch) {
  return {
    dispatch,
  };
}

const withConnect = connect(
  mapStateToProps,
  mapDispatchToProps,
);

export default compose(
  withConnect,
  memo,
)(NetBalance);
/*




  const [flag, setflag] = useState({t:false});

  const handleInputChange = (e, index) => {
   
    const { name, value } = e.target;
    const list = [...inputList];
   
    list[index][name] = value;
    setInputList(list);
  };

  const handleAddClick = () => {
    setflag({t:true})
    setInputList([...inputList, 
      { id :(Math.floor(Math.random() * 99 + 100)).toString(),
        noteName: "", amt: "" }]);
  };

  const handleAddCI = () => { 
    props.addCI(inputList); 
  };

  const submitData = () => { 
    var s_id="1"
    var d_id="101" 
    var newEmployee=[];
    newEmployee.push(state);
    newEmployee.push(state2);
    console.log("emp",newEmployee)
    console.log(inputList.length)
    for (var i=0;i<inputList.length;i++){
      if(inputList[i].amt!==""){
      newEmployee.push(inputList[i])
      }
    }
    //props.addCI(inputList); 
    console.log(state);
    console.log(state2);
   console.log(newEmployee)
       // state.concat(state2)
       console.log(props.example.sheets.length)
       console.log(props.example.sheets[0].data.length)
     console.log(state);
     props.addCI(newEmployee,s_id,d_id);
     //console.log(parseInt(props.example.sheets[0].data[0].data[0].amt))
     clearData();
    
  } 




   useInjectReducer({ key: 'netBalance', reducer });
  useInjectSaga({ key: 'netBalance', saga });



  const [inputList, setInputList] = useState([{ id :(Math.floor(Math.random() * 99 + 100)).toString(), noteName: "", amt: "" }]);
  const [state, setState] = useState({id:"", noteName:"", amt:"" });
  const handleChange=(e,i,j)=>{
    const name= e.target.name;
   const value= e.target.value;
  const d= props.example.sheets[i].data[j].data.filter(l=>l.noteName===name)
   console.log(j)
     
    setState({id:d[0].id,noteName:d[0].noteName,amt:value})
   
  };
  const [state2, setState2] = useState({id:"", noteName:"", amt:"" });
  const handleChange2=(e,i,j)=>{
    const {name,value}= e.target;
    const c=props.example.sheets[i].data[j].data.filter(d=>d.noteName===name)
    console.log(c[i])
      setState2({id:c[0].id,noteName:c[0].noteName,amt:value})
    console.log(state2)
  };




 <FixedForm  name="cash" name2="cash2" i={0} j={0}  state={state} state2={state2} handleChange={handleChange} handleChange2={handleChange2}/>
 
      <Form inputList={inputList} flag={flag} setflag={setflag}  handleInputChange={handleInputChange} handleAddClick={handleAddClick}/>
     
      
       {inputList.length - 1 === i && <button onClick={handleAddClick}>Add</button>}  
      <button onClick={submitData}>ADD</button> 

















*/

import React, { Component } from "react";
//import './style.css'
import {Container, Col, Row } from 'react-bootstrap';
import 'bootstrap/dist/css/bootstrap.css';
//import '../../components/AddInput/node_modules/bootstrap/dist/css/bootstrap.css'
import TextInput from 'components/TextInput/Index';
import { connect } from "react-redux";
//import { formValues } from "redux-form";
//import TextInput from './component/TextInput';





export default function FixedForm(props) {

return(
    <div>
    cash: <input onChange={(e)=>props.handleChange(e,props.i,props.j)}  name={props.name} value={props.state.amt} type="text" /> <br />  
   cash2 :  <input onChange={(e)=>props.handleChange2(e,props.i,props.j)}  name={props.name2} value={props.state2.amt} type="text" /><br /> 
   </div>
)
}

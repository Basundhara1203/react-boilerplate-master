// import { selectRegistrationDomain } from '../selectors';

describe('selectRegistrationDomain', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(false);
  });
});

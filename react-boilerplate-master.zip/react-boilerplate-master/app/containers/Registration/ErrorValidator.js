/*export const onValidation=(e)=>{
    let ErrorSet=""
    const name=e.target.name;
    const value=e.target.value;

    if(value==="")
    {
        ErrorSet=`${name} 'Required!!`

    }
 
    return ErrorSet;
}
*/

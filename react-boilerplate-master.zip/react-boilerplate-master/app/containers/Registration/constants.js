/*
 *
 * Registration constants
 *
 */

export const DEFAULT_ACTION = 'app/Registration/DEFAULT_ACTION';
export const SET_FORMVALUES="SET_FORMVALUES";
export const SUBMIT_FORM="SUBMIT_FORM";
export const onReset="onReset";


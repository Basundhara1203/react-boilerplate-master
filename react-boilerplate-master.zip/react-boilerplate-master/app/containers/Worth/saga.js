// import { take, call, put, select } from 'redux-saga/effects';

// Individual exports for testing

import { call, put, takeEvery,takeLatest } from 'redux-saga/effects'
import axios from 'axios'
// Individual exports for testing
import {CREATE_SUBSCRIBER,EDIT_LABEL,EDIT_AMT,CANCEL_FORMS} from './constants'
import { all } from 'redux-saga/effects'

import request from 'utils/request'
import {
  getUsersFailed,getUsersSuccess,getUsers,createUserSuccess,createUserFailed,createSubscriber,editamt,labelInputChange
} from './actions'

const requestURL="http://localhost:3001/Worth/"
const token=localStorage.getItem("Token");
const header={
  'Accept':'application/json',
  'authentication':`bearerToken`+` `+`${token}`,
  'Content-Type':'application/json'
}

function* fetchEmployees(action) {
 try {
     const employees =  yield call(()=>request((requestURL+"list"),{
      method:"GET",
      headers:header}));
     const users=employees
    // console.log(JSON.stringify(users))
     yield put(getUsersSuccess(users) );
  } catch (e) {
     //yield put({type: 'GET_EMPLOYEES_FAILED', message: e.message});
     yield put(getUsersFailed(e));
  }
}
function* requestSaga() {
  // yield takeEvery('GET_EMPLOYEES_REQUESTED', fetchEmployees);
  yield takeEvery(getUsers, fetchEmployees);
}



function* createEmp(action) {
  try {
    const subscriber  = action.body;
    const subscriberDetails=yield call(()=>request((requestURL+"add"),{
       method:"POST",
       headers:header,
          body:JSON.stringify(subscriber)

       }
    ))
   yield put(getUsers());
  
     
  } catch (error) {

    alert(error+"  Enter Employee Details Correctly")

    yield put(createUserFailed(error));
  }
}

function* watchCreateUserRequest(){
  yield takeLatest(CREATE_SUBSCRIBER, createEmp);
}





function* EditLabel(action) {
  try {
    const { data } = action;  
    const subscriberDetails=yield call(()=>request((requestURL+`updatelabel/${data.id}`),{
       method:"PUT",
       headers:header,
          body:JSON.stringify(data)
       }
    ))
     yield put(getUsers());
     
  } catch (error) {
  }
}

function* watchEDITLABELRequest(){
  yield takeLatest(EDIT_LABEL, EditLabel);
}



function* EditEmployee(action) {
  try {
    const { data } = action;
    console.log(data.id);  
    const subscriberDetails=yield call(()=>request((requestURL+`update/${data.id}`),{
       method:"PUT",
       headers:
        header,
          body:JSON.stringify(data)
       }
    ))
   
    yield put(getUsers());
     
  } catch (error) {
  }
}

function* watchEDITUserRequest(){
  yield takeLatest(EDIT_AMT, EditEmployee);
}


function* CancelForms(action) {
  try {
    const subscriber  = action.body;

    console.log(subscriber);
   
    const subscriberDetails=yield call(()=>request((requestURL+"cancel"),{
       method:"POST",
       headers:header,
          body:JSON.stringify(subscriber)

       }
    ))
   yield put(getUsers());
  
     
  } catch (error) {

    alert(error+"  Enter Employee Details Correctly")

    yield put(createUserFailed(error));
  }
}




function* watchCancelFormRequest(){
  yield takeLatest(CANCEL_FORMS, CancelForms);
}

export default function* worthSaga() {
  // See example in containers/HomePage/saga.js
  yield all([
    requestSaga(),
    watchCreateUserRequest(),
    watchEDITUserRequest(),
    watchCancelFormRequest(),
    watchEDITLABELRequest()
  ])
}

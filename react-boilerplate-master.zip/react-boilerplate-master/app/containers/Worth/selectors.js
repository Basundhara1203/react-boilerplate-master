import { createSelector } from 'reselect';
import { initialState } from './reducer';

/**
 * Direct selector to the worth state domain
 */

const selectWorthDomain = state => state.worth || initialState;

/**
 * Other specific selectors
 */

/**
 * Default selector used by Worth
 */

const makeSelectWorth = () =>
  createSelector(
    selectWorthDomain,
    substate => substate,
  );

export default makeSelectWorth;
export { selectWorthDomain };

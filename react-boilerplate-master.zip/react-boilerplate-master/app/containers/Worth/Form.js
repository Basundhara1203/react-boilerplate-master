import React, { memo } from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { Helmet } from 'react-helmet';
import { FormattedMessage } from 'react-intl';
import { createStructuredSelector } from 'reselect';
import { compose } from 'redux';

import { useInjectSaga } from 'utils/injectSaga';
import { useInjectReducer } from 'utils/injectReducer';
import makeSelectNet from './selectors';
import reducer from './reducer';
import saga from './saga';
import messages from './messages';
import {Container, Col, Row,Table } from 'react-bootstrap';
//import '../AddInput/node_modules/bootstrap/dist/css/bootstrap.css';
import 'bootstrap/dist/css/bootstrap.css';
//import '../style.css';
import {Wrapper,line} from 'components/FixedInput2/Wrapper'
import StyledText from 'components/FixedInput2/StyledText';
import StyledSubmit from 'components/FormSave/StyledSubmit';

export function Form(props) {

 return(

<div>
<Table>
  <th>Total  {props.division.budget_name}</th>
  <th>
      ${props.calculationForm(props.i,props.j)}
  </th>
</Table>
 
 {props.division && props.division.data.map((field,k)=>{
    let text=(
      <Table>
      <tr>
                <td style={{width:500}}> { field.noteName.length<6?<input id={props.i.toString()+props.j.toString()+k.toString()}   type="text" onChange={(e)=>props.labelChange(e)}/>:
     <label>{field.noteName}</label>}

               </td>
               <td>  <StyledText className="input col-5"  id={props.i.toString()+props.j.toString()+k.toString()} name={field.noteName} defaultValue={field.amt} type="text" onChange={(e)=>props.handleInputChange(e)}/></td>
               </tr>
                </Table>)
      
  return <Wrapper>{text}</Wrapper>
}
   

  ) }
  <button onClick={()=> props.addMore(props.i.toString()+props.j.toString())}>addMore</button>
  <div>
  <StyledSubmit onClick={()=> props.submitSave()} className="mr-3" >Save</StyledSubmit>
  <button  onClick={()=>props.CancelForm(props.i.toString()+props.j.toString())} className="mr-5" >Cancel</button>
  </div>
</div>
 )
}

/* {props.flag?<div>
        <input type="text" id="id1" name="noteName"/>
        <input type="text" id="id2" name="amt"/>
      </div>:<div></div>}
      
      function TextInput(props)
{
   // console.log(props);
    let text=(
        <Table>
            <tr>
                <td style={{width:500}}>
                <label>
                        {props.form.noteName}
                </label>
                </td>
                


                <td>
                <StyledText className="input col-5" type="type"                  
                            name={props.form.noteName} defaultValue={props.form.amt}
                            onChange={(e)=>props.handleChange(e,props.i,props.j,props.r)} />
                           
                            

                        
            

                   
                </td>
                
            </tr>
        
           
            </Table>
            
    );
    return <Wrapper>{text}</Wrapper>
}

      
      */
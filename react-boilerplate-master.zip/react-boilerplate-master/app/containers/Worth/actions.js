/*
 *
 * Worth actions
 *
 */

import { DEFAULT_ACTION } from './constants';

export function defaultAction() {
  return {
    type: DEFAULT_ACTION,
  };
}

export function getUsers() {

 
  return {

    
      // event:e,
       type: "GET_EMPLOYEES_REQUESTED",
  }
  
}


export function getUsersFailed(e) {
  return {


         type: "GET_EMPLOYEES_FAILED",
         message: e.message

  }
}


export function getUsersSuccess(users) {
  return {


    type:"GET_EMPLOYEES_SUCCESS",
    users:users

  }
}

export function handleChange(e) {
  console.log("action  ",e.target)
  return {
    type:"ONCHANGE_ACTION",
    name:e.target.name,
    value:e.target.value,
    sheet:e.target.id[0],
    data1:e.target.id[1],
    data2:e.target.id[2]
  };
}
export function click() {
  return {
    type:"CLICK",
   
  };
}

export function editamt(data) {  
  // return dispatch => {  
       return {
       //dispatch({  
           type: 'EDIT_AMT',  data
          // payload: data  
       };  
   
 }; 


 export function labelInputChange(data){
  return {
    //dispatch({  
        type: 'EDIT_LABEL',  data
       // payload: data  
    };  

 }
export function createUserSuccess(subscriber) {
  return { type: 'CREATE_USER_SUCCESS', 
            body:subscriber ,
            //token:token
};

}
export function createUserFailed(error) {
  return { type: 'CREATE_USER_Failed', 
            error:error 
            //token:token
    };

 

}

export function createSubscriber(subscriber) {
  return { type: 'CREATE_SUBSCRIBER', 
            body:subscriber ,
            //token:token
    };
}

export function CancelForms(data) {
  return { type: 'CANCEL_FORMS', 
            body:data ,
            //token:token
    };
}
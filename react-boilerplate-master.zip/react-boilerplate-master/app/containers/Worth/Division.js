import React, { memo } from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { Helmet } from 'react-helmet';
import { FormattedMessage } from 'react-intl';
import { createStructuredSelector } from 'reselect';
import { compose } from 'redux';
import Accordion from 'react-bootstrap/Accordion'
import Card from 'react-bootstrap/Card'
import 'bootstrap/dist/css/bootstrap.css';
import {Form} from './Form'

import { useInjectSaga } from 'utils/injectSaga';
import { useInjectReducer } from 'utils/injectReducer';
import makeSelectNet from './selectors';
import reducer from './reducer';
import saga from './saga';
import messages from './messages';

export function Division(props) {

 return(

<div>
 {props.sheet && props.sheet.data && props.sheet.data.map((division,j)=>{
    return(
    <div>
    <Accordion defaultActiveKey="6" >
          <Card>
         
          <Accordion.Toggle as={Card.Header} style={{backgroundColor: "white",height:40}} eventKey="0">
          <b>+ {division.budget_name}</b>
            </Accordion.Toggle>   
            <Accordion.Collapse eventKey="0">
              <Card.Body>
              <Form division={division} i={props.i} j={j} labelChange={props.labelChange} store={props.store} CancelForm={props.CancelForm} addMore={props.addMore} flag={props.flag} submitSave={props.submitSave} calculationForm={props.calculationForm} createSubscriber={props.createSubscriber} handleInputChange={props.handleInputChange}/>
              </Card.Body>
            </Accordion.Collapse>
            
          </Card>
          </Accordion>

    
    
  
          
    

</div>
  ) })}
  
</div>
 )
}


/**
 *
 * Worth
 *
 */

import React, { memo ,useEffect,useState} from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { Helmet } from 'react-helmet';
import { FormattedMessage } from 'react-intl';
import { createStructuredSelector } from 'reselect';
import { compose } from 'redux';
import { useSelector, useDispatch } from 'react-redux';
import {Division} from './Division'
import Calculation from './Calculation'
import {Choice} from 'containers/LoginPage/Choice';
//import Wrapper from 'components/UpperDiv/Wrapper';

import { useInjectSaga } from 'utils/injectSaga';
import { useInjectReducer } from 'utils/injectReducer';
import makeSelectWorth from './selectors';
import reducer from './reducer';
import saga from './saga';
import messages from './messages';
//import Calculation from 'components/Calculation/Index';
import FormWrapper from 'components/FormWrapper/FormWrapper';
import Wrapper from 'components/UpperDiv/Wrapper';
import {getUsers,createSubscriber,handleChange,editamt,labelInputChange,CancelForms} from './actions'

export function Worth(props) {
  useInjectReducer({ key: 'worth', reducer });
  useInjectSaga({ key: 'worth', saga });

  const dispatch = useDispatch();
  useEffect(() => {
    dispatch(getUsers()
    );
    
  }, [])
  const [flag, setflag] = useState(false);
  const datalist={asset:0,liability:0,net:0}

  const handleInputChange=(e)=>{
    const data = {  
      id:e.target.id,  
      
      amt: e.target.value,  
    };
    props.editamt(data);
  }


  const  labelChange=(e)=>{
    
    const data = {  
      id:e.target.id,  
      
      noteName: e.target.value,  
    };
    props.labelInputChange(data);
  }

  const addMore=(id)=>{
    //setflag(true)
    const data={
      id1:id[0],
      id2:id[1]
    }
    props.createSubscriber(data)
   
  }

  const CancelForm=(id)=>{
    //setflag(true)
    const data={
      id1:id[0],
      id2:id[1]
    }
    props.CancelForms(data)
   
  }
  const  submitSave=()=>{
  //  setflag(true)
  console.log("ok")
   let datalist= cal()
   console.log(datalist)
    setState3({
      asset:datalist.asset,
      liability:datalist.liability,
      net:datalist.net
})
  }


   
  const calculationForm=(i,j)=>{
    var sum1=0;  
     var sum2=0;
     console.log(props.worth.sheets[i].data[j])
    // if(props.worth.sheets.length!==0){
    for (var b=0;b<(props.worth.sheets[i].data[j].data.length);b++)
    {
      //for(var k=0;k<(props.worth.sheets[0].data[b].data.length);k++){
         sum1=sum1+parseInt(props.worth.sheets[i].data[j].data[b].amt)
         
      
    }
  
      console.log(sum1)
        return sum1
  }


  const calculationAsset=()=>{
    var sum1=0;  
     var sum2=0;
     console.log(props.worth.sheets)
     if(props.worth.sheets.length!==0){
    for (var b=0;b<(props.worth.sheets[0].data.length);b++)
    {
      for(var k=0;k<(props.worth.sheets[0].data[b].data.length);k++){
         sum1=sum1+parseInt(props.worth.sheets[0].data[b].data[k].amt)
         
      }
    }
  }
      console.log(sum1)
        return sum1

   }
    
   const calculationLiability=()=>{
    var sum1=0;  
     if(props.worth.sheets.length!==0){
    for (var b=0;b<(props.worth.sheets[1].data.length);b++)
    {
      for(var k=0;k<(props.worth.sheets[1].data[b].data.length);k++){
         sum1=sum1+parseInt(props.worth.sheets[1].data[b].data[k].amt)
         
      }
    }
  }
        return sum1

   }


   const calculationNet=()=>{
    var sum1=0;  
     var sum2=0;
     if(props.worth.sheets.length!==0){
    for (var b=0;b<(props.worth.sheets[0].data.length);b++)
    {
      for(var k=0;k<(props.worth.sheets[0].data[b].data.length);k++){
         sum1=sum1+parseInt(props.worth.sheets[0].data[b].data[k].amt)
         
      }
    }

    for (var v=0;v<(props.worth.sheets[1].data.length);v++)
    {
      for(var s=0;s<(props.worth.sheets[1].data[v].data.length);s++){
         sum2=sum2+parseInt(props.worth.sheets[1].data[v].data[s].amt)
         
      }
    }
  }
        return (sum1-sum2)

   }
   const [state3, setState3] = useState({asset:0, liability:0, net:0 });
   
  const cal=()=>{
    var sum1=0;
    var sum2=0;
    var netsum=0
    if(props.worth.sheets){
    for (var b=0;b<(props.worth.sheets[0].data.length);b++)
    {
      for(var k=0;k<(props.worth.sheets[0].data[b].data.length);k++){
         sum1=sum1+parseInt(props.worth.sheets[0].data[b].data[k].amt)
         
      }

    }
    console.log(sum1)

    for (var b=0;b<(props.worth.sheets[1].data.length);b++)
    {
      for(var k=0;k<(props.worth.sheets[1].data[b].data.length);k++){
         sum2=sum2+parseInt(props.worth.sheets[1].data[b].data[k].amt)
         
      }
    }
   
    netsum=sum1-sum2;
  }
 
  datalist.asset=sum1
  datalist.liability=sum2
  datalist.net=netsum
 // if(flag===true){
   
   // setflag(false)
  //}
 // console.log(state3)
  console.log(datalist)
  return datalist
  }


  return (
    
   // console.log(calculationAsset()),
    <div>
      <Helmet>
        <title>Worth</title>
        <meta name="description" content="Description of Worth" />
      </Helmet>
     
      <div>
      <Choice/>
      <h3><center>Net <em style={{fontFamily:"cursive",color:"gray"}}>worth</em></center></h3>
      <Wrapper>
        <h6><b>Summary</b></h6>
         <Calculation  calculate={calculationAsset}  state={state3.asset} fieldname="Total Assets"/>
         <Calculation  calculate={calculationLiability} state={state3.liability} fieldname="Total Liabilities"/>
         <Calculation  calculate={calculationNet} state={state3.net} fieldname="You have a net Worth"/>
      </Wrapper>

     
      </div>
      <div>
      <FormWrapper>
      {props.worth && props.worth.sheets && props.worth.sheets.map((sheet,i)=>
      <div>
      <h5 style={{marginTop:20}}><b>{sheet.categories_name}</b></h5>
      <Division i={i} sheet={sheet} store={props.worth} labelChange={labelChange} CancelForm={CancelForm} submitSave={submitSave} flag={flag} addMore={addMore} createSubscriber={props.createSubscriber} calculationForm={calculationForm} handleInputChange={handleInputChange}/>
      </div>
      )}
      </FormWrapper>
      </div>
     
    </div>
  );
}

Worth.propTypes = {
  dispatch: PropTypes.func.isRequired,
};

const mapStateToProps = createStructuredSelector({
  worth: makeSelectWorth(),
});

function mapDispatchToProps(dispatch) {
  return {
    dispatch,
    handleChange:(e)=>{dispatch(handleChange(e))},
    createSubscriber:(data)=>{dispatch(createSubscriber(data))},
    editamt:(data)=>{dispatch(editamt(data))},
    labelInputChange:(data)=>{dispatch(labelInputChange(data))},
    CancelForms:(data)=>{dispatch(CancelForms(data))}
  };
}

const withConnect = connect(
  mapStateToProps,
  mapDispatchToProps,
);

export default compose(
  withConnect,
  memo,
)(Worth);

































































































































































































/*

/**
 

import React, { memo ,useEffect,useState} from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { Helmet } from 'react-helmet';
import { FormattedMessage } from 'react-intl';
import { createStructuredSelector } from 'reselect';
import { compose } from 'redux';
import { useSelector, useDispatch } from 'react-redux';
import {Division} from './Division'

import { useInjectSaga } from 'utils/injectSaga';
import { useInjectReducer } from 'utils/injectReducer';
import makeSelectWorth from './selectors';
import reducer from './reducer';
import saga from './saga';
import messages from './messages';
import Calculation from 'components/Calculation/Index';
import Wrapper from 'components/UpperDiv/Wrapper';
import {getUsers,createSubscriber,handleChange,editamt,labelInputChange} from './actions'

export function Worth(props) {
  useInjectReducer({ key: 'worth', reducer });
  useInjectSaga({ key: 'worth', saga });

  const dispatch = useDispatch();
  useEffect(() => {
    dispatch(getUsers()
    );
    
  }, [])
  const [flag, setflag] = useState(false);
  


  const datalist={asset:0,liability:0,net:0}

  const handleInputChange=(e)=>{
    const data = {  
      id:e.target.id,  
      
      amt: e.target.value,  
    };
    props.editamt(data);
  }


  


  const  labelChange=(e)=>{
    
    const data = {  
      id:e.target.id,  
      
      noteName: e.target.value,  
    };
    props.labelInputChange(data);
  }

  const addMore=(id)=>{
    //setflag(true)
    const data={
      id1:id[0],
      id2:id[1]
    }
    props.createSubscriber(data)
   
  }
  const  submitSave=()=>{
  //  setflag(true)
  console.log("ok")
   let datalist= cal()
   console.log(datalist)
    setState3({
      asset:datalist.asset,
      liability:datalist.liability,
      net:datalist.net
})
  }


   
  const calculationForm=(i,j)=>{
    var sum1=0;  
     var sum2=0;
     console.log(props.worth.sheets[i].data[j])
    // if(props.worth.sheets.length!==0){
    for (var b=0;b<(props.worth.sheets[i].data[j].data.length);b++)
    {
      //for(var k=0;k<(props.worth.sheets[0].data[b].data.length);k++){
         sum1=sum1+parseInt(props.worth.sheets[i].data[j].data[b].amt)
         
      
    }
  
      console.log(sum1)
        return sum1
  }


  const calculationAsset=()=>{
    var sum1=0;  
     var sum2=0;
     console.log(props.worth.sheets)
     if(props.worth.sheets.length!==0){
    for (var b=0;b<(props.worth.sheets[0].data.length);b++)
    {
      for(var k=0;k<(props.worth.sheets[0].data[b].data.length);k++){
         sum1=sum1+parseInt(props.worth.sheets[0].data[b].data[k].amt)
         
      }
    }
  }
      console.log(sum1)
        return sum1

   }
    
   const calculationLiability=()=>{
    var sum1=0;  
     if(props.worth.sheets.length!==0){
    for (var b=0;b<(props.worth.sheets[1].data.length);b++)
    {
      for(var k=0;k<(props.worth.sheets[1].data[b].data.length);k++){
         sum1=sum1+parseInt(props.worth.sheets[1].data[b].data[k].amt)
         
      }
    }
  }
        return sum1

   }


   const calculationNet=()=>{
    var sum1=0;  
     var sum2=0;
     if(props.worth.sheets.length!==0){
    for (var b=0;b<(props.worth.sheets[0].data.length);b++)
    {
      for(var k=0;k<(props.worth.sheets[0].data[b].data.length);k++){
         sum1=sum1+parseInt(props.worth.sheets[0].data[b].data[k].amt)
         
      }
    }

    for (var v=0;v<(props.worth.sheets[1].data.length);v++)
    {
      for(var s=0;s<(props.worth.sheets[1].data[v].data.length);s++){
         sum2=sum2+parseInt(props.worth.sheets[1].data[v].data[s].amt)
         
      }
    }
  }
        return (sum1-sum2)

   }
   const [state3, setState3] = useState({asset:0, liability:0, net:0 });
   
  const cal=()=>{
    var sum1=0;
    var sum2=0;
    var netsum=0
    if(props.worth.sheets){
    for (var b=0;b<(props.worth.sheets[0].data.length);b++)
    {
      for(var k=0;k<(props.worth.sheets[0].data[b].data.length);k++){
         sum1=sum1+parseInt(props.worth.sheets[0].data[b].data[k].amt)
         
      }

    }
    console.log(sum1)

    for (var b=0;b<(props.worth.sheets[1].data.length);b++)
    {
      for(var k=0;k<(props.worth.sheets[1].data[b].data.length);k++){
         sum2=sum2+parseInt(props.worth.sheets[1].data[b].data[k].amt)
         
      }
    }
   
    netsum=sum1-sum2;
  }
 
  datalist.asset=sum1
  datalist.liability=sum2
  datalist.net=netsum
 // if(flag===true){
   
   // setflag(false)
  //}
 // console.log(state3)
  console.log(datalist)
  return datalist
  }




 

  return (
    
   // console.log(calculationAsset()),
    <div>
      <Helmet>
        <title>Worth</title>
        <meta name="description" content="Description of Worth" />
      </Helmet>
      <FormattedMessage {...messages.header} />
      <div>
      {state3.asset===0?
      <div><h5>{calculationAsset()}</h5>
      <h5>{calculationLiability()}</h5>
      <h5>{calculationNet()}</h5>
      </div>:
      <div>
      <h5>{state3.asset}</h5>
      <h5>{state3.liability}</h5>
      <h5>{state3.net}</h5>
      </div>}
      </div>
      <div>
      {props.worth && props.worth.sheets && props.worth.sheets.map((sheet,i)=>
      <div>
      <h5>{sheet.categories_name}</h5>
      <Division i={i} sheet={sheet} store={props.worth} labelChange={labelChange} submitSave={submitSave} flag={flag} addMore={addMore} createSubscriber={props.createSubscriber} calculationForm={calculationForm} handleInputChange={handleInputChange}/>
      </div>
      )}
      </div>
      <div>
        {JSON.stringify(props.worth.sheets)}
      </div>
    </div>
  );
}

Worth.propTypes = {
  dispatch: PropTypes.func.isRequired,
};

const mapStateToProps = createStructuredSelector({
  worth: makeSelectWorth(),
});

function mapDispatchToProps(dispatch) {
  return {
    dispatch,
    handleChange:(e)=>{dispatch(handleChange(e))},
    createSubscriber:(data)=>{dispatch(createSubscriber(data))},
    editamt:(data)=>{dispatch(editamt(data))},
    labelInputChange:(data)=>{dispatch(labelInputChange(data))}
  };
}

const withConnect = connect(
  mapStateToProps,
  mapDispatchToProps,
);

export default compose(
  withConnect,
  memo,
)(Worth);


*/











































































































































































































































































































































































































































































































































































































import React from 'react';
import {Container, Col, Row,Table } from 'react-bootstrap';
//import '../AddInput/node_modules/bootstrap/dist/css/bootstrap.css';
import 'bootstrap/dist/css/bootstrap.css';
//import '../style.css';
import {Wrapper,line} from 'components/Calculation/Wrapper'
import StyledText from 'components/Calculation/StyledText';




function Calculation(props)
{
   // console.log(props);
    let text=(
        <Table>   
            <tr>
                <td style={{width:550}}>
                   {props.fieldname}
                </td>
                {props.state===0 ?
                <td>
                ${props.calculate()}
                </td>:
                <td>
                 ${props.state}
                </td>}
            </tr>
            </Table>
            
    );
    return <Wrapper>{text}</Wrapper>
}





  
export default Calculation;




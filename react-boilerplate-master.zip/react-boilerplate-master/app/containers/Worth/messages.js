/*
 * Worth Messages
 *
 * This contains all the text for the Worth container.
 */

import { defineMessages } from 'react-intl';

export const scope = 'app.containers.Worth';

export default defineMessages({
  header: {
    id: `${scope}.header`,
    defaultMessage: 'This is the Worth container!',
  },
});

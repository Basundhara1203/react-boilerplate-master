/**
 *
 * Asynchronously loads the component for Worth
 *
 */

import loadable from 'utils/loadable';

export default loadable(() => import('./index'));

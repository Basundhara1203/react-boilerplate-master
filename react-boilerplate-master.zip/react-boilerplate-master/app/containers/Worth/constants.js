/*
 *
 * Worth constants
 *
 */

export const DEFAULT_ACTION = 'app/Worth/DEFAULT_ACTION';
export const CREATE_SUBSCRIBER='CREATE_SUBSCRIBER'
export const EDIT_LABEL='EDIT_LABEL'
export const EDIT_AMT='EDIT_AMT'
export const CANCEL_FORMS='CANCEL_FORMS'

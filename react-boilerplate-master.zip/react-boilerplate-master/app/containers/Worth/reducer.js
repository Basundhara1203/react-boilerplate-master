/*
 *
 * Worth reducer
 *
 */
import produce from 'immer';
import { DEFAULT_ACTION } from './constants';

export const initialState = {
  sheets:[]
};

/* eslint-disable default-case, no-param-reassign */
const worthReducer = (state = initialState, action) =>
  produce(state, (/* draft */) => {
    switch (action.type) {
      case DEFAULT_ACTION:
        break;
        case "GET_EMPLOYEES_REQUESTED":
        
          return {
            ...state,
            isloading: true,
           
          }
        case "GET_EMPLOYEES_SUCCESS":
            //console.log("reducer",action.users)
         return {
            ...state,
            isloading: false,
            sheets: action.users,
            
            
          }

          case 'ONCHANGE_ACTION':
            console.log(state.data)
            console.log(action)

            return {    
            ...state,
            
            ...(state.sheets[action.sheet].data[action.data1].data[action.data2].amt=action.value)}


            case 'CREATE_USER_FAILED':
            return { ...state, isloading: false, error: action.error };


            case 'CREATE_USER_SUCCESS':
              
                return { ...state, };


    }
  });

export default worthReducer;

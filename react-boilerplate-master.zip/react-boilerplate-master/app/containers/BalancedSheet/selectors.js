import { createSelector } from 'reselect';
import { initialState } from './reducer';

/**
 * Direct selector to the balancedSheet state domain
 */

const selectBalancedSheetDomain = state => state.balancedSheet || initialState;

/**
 * Other specific selectors
 */

/**
 * Default selector used by BalancedSheet
 */

const makeSelectBalancedSheet = () =>
  createSelector(
    selectBalancedSheetDomain,
    substate => substate,
  );

export default makeSelectBalancedSheet;
export { selectBalancedSheetDomain };

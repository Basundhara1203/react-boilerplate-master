/*
 *
 * BalancedSheet reducer
 *
 */
import produce from 'immer';
import { DEFAULT_ACTION } from './constants';

export const initialState = {sheet:[

/*
  { id :"1",categories_name: "assets", data:  
                    [
                      {id :"101", categories_name: "cash and investments",data:[]},
                      {id :"102", categories_name: "Long-Term Assets",data:[]},
                      {id :"103", categories_name: "Property Assets",data:[]}
                    ]
                    },
                    { id :"2",categories_name: "Liabilities", data: 
                    [
                      {id :"201", categories_name: "Short-Term Liabilities",data:[]},
                      {id :"301", categories_name: "Mid and Long-Term Liabilities",data:[]}
                      ]
                    }



   id :"1",categories_name: "assets", data:  
                    [
                      {id :"101", categories_name: "cash and investments",data:[]},
                      
                    ]}
                    
                  

                      
                    */
]};

/* eslint-disable default-case, no-param-reassign */
const balancedSheetReducer = (state = initialState, action) =>
  produce(state, ( /*draft*/ ) => {
    switch (action.type) {
      case 'ADD_CI':    
     
     /* const content = state.sheet[0].templates[state.templateKey].items[
        state.itemKey
      ].properties.text.value =
        action.value;

      return { ...state, content };*/
     
      return {    
         ...state,  
         sheet:action.payload  
          //sheet: state.sheet.data.data.concat(action.payload)   
         // sheet:action.payload 
        /* myPosts: {
          ...state.myPosts,
          isPending: true,*/
          //data:(action.payload)
         // draft[0].sheet[0].data[0].data=action.payload,                                                                                                                                                                                                                                                                                                                                                                                                                                                            
        //state.sheet[0].data[0].data.concat(action.payload)
      //  { 
         /* ...state.sheet,
          data:{
            ...state.sheet.data,
            data:(action.payload) ,
          }*/
        }

        case 'ADD_ST':
          return {    
            ...state,  
            sheet: state.sheet.concat(action.payload) 
           }

        
      }; 




    }
 // }
 );

export default balancedSheetReducer;

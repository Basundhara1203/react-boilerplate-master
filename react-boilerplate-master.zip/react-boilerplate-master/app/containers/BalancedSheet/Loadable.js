/**
 *
 * Asynchronously loads the component for BalancedSheet
 *
 */

import loadable from 'utils/loadable';

export default loadable(() => import('./index'));

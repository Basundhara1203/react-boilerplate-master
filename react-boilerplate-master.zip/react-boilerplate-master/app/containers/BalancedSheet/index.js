/**
 *
 * BalancedSheet
 *
 */

import React, { memo,useState } from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { Helmet } from 'react-helmet';
import { FormattedMessage } from 'react-intl';
import { createStructuredSelector } from 'reselect';
import Accordion from 'react-bootstrap/Accordion'
import Card from 'react-bootstrap/Card'
import { compose } from 'redux';
import Button from 'react-bootstrap/Button'
import Collapse from 'react-bootstrap/Collapse'
import 'bootstrap/dist/css/bootstrap.css';
//import Collapse from '@bit/react-bootstrap.react-bootstrap.collapse';
//import Button from '@bit/react-bootstrap.react-bootstrap.button';
//import ReactBootstrapStyle from '@bit/react-bootstrap.react-bootstrap.internal.style-links';
import {addCI,addST} from './actions';
import { useInjectSaga } from 'utils/injectSaga';
import { useInjectReducer } from 'utils/injectReducer';
import makeSelectBalancedSheet from './selectors';
import reducer from './reducer';
import saga from './saga';
import messages from './messages';

export function BalancedSheet(props) {
 // const [Asset, setAsset] = useState([{ id :"", categories_name: "", data: [{id :"", categories_name: "",data:""}] }]);
 const [LA, setLA] = useState([{ id :"", budgetname: "", data: [] }]);
 const [inputList4, setInputList4] = useState([{ id :(Math.floor(Math.random() * 99 + 100)).toString(), firstName: "", lastName: "" }]);
  const [inputList2, setInputList2] = useState([{ id :(Math.floor(Math.random() * 99 + 100)).toString(), firstName: "", lastName: "" }]);
  const [Asset, setAsset] = useState([{ id :"", categories_name: "", data: [{id :"", budgetname: "",data:""}] }]);
  const [Liability, setLiability] = useState([{ id :"", categories_name: "", data: [{id :"", budgetname: "",data:""}] }]);
  const [CI, setCI] = useState([{ id :"", budgetname: "", data: [] }]);
  const [inputList, setInputList] = useState([{ id :(Math.floor(Math.random() * 99 + 100)).toString(), firstName: "", lastName: "" }]);
  const [open, setOpen] = useState(false);
  useInjectReducer({ key: 'balancedSheet', reducer });
  useInjectSaga({ key: 'balancedSheet', saga });



  const handleInputChange = (e, index) => {
    //id=(Math.floor(Math.random() * 99 + 100)).toString();
    const { name, value } = e.target;
    const list = [...inputList];
   
    list[index][name] = value;
    setInputList(list);
  };

  // handle click event of the Remove button
 

  // handle click event of the Add button
  const handleAddClick = () => {
    setInputList([...inputList, { id :(Math.floor(Math.random() * 99 + 100)).toString(),firstName: "", lastName: "" }]);
  };

  const handleAddCI = () => {

    //props.addCI(inputList); 
    /*if(CI.id){
      setCI([...CI, {id :CI.id,data: inputList}]);
    }
    else{
    setCI([...CI, { id :"101",budgetname: "cash and investments", data: inputList}]);
    }*/
    console.log(inputList)
    setAsset({ id :"1",categories_name: "assets", data:  [{id :"101", budgetname: "cash and investments",data:inputList}]});
    console.log(Asset)
    //props.addCI(Asset); 
    props.addCI(Asset); 
  };
  const handleInputChange2 = (e, index) => {
    //id=(Math.floor(Math.random() * 99 + 100)).toString();
    const { name, value } = e.target;
    const list2 = [...inputList2];
   
    list2[index][name] = value;
    setInputList2(list2);
    
  };



  const handleAddLA = () => {

     if(Asset.id){
       
     // setAsset([...Asset,{data:{ id :"102", budgetname: "LongtermAsset",data:inputList2}}]);
     
     setAsset({...Asset,data:[{ 
       ...Asset.data,data:[{id :"102", budgetname: "LongtermAsset",data:inputList2}]}]});
     }
     else
    setAsset({ id :"1",categories_name: "assets", data:  [{id :"102", budgetname: "LongtermAsset",data:inputList2}]});
    console.log(Asset)
    /*
    setLA({ id :"102", budgetname: "LongtermAsset",data:inputList2});
   
    console.log(LA);
    const Assets=Assets.push(LA);
    //props.addCI(Asset); 
    setAsset({ id :"1",categories_name: "assets", data:Assets});
   // props.addCI(Asset); 
   */
  };





  const handleAddClick4 = () => {
    setInputList4([...inputList4, { id :(Math.floor(Math.random() * 99 + 100)).toString(),firstName: "", lastName: "" }]);
  };


  const handleInputChange4 = (e, index) => {
    //id=(Math.floor(Math.random() * 99 + 100)).toString();
    const { name, value } = e.target;
    const list4 = [...inputList4];
   
    list4[index][name] = value;
    setInputList4(list4);
    
  };



  const handleAddST = () => {

     if(Liability.id){
       
      setLiability([...Liability.data,{ id :"201", budgetname: "Short-Term",data:inputList4}]);
    
     }
     else
    setLiability({ id :"2",categories_name: "liability", data:  [{id :"201", budgetname: "LongtermAsset",data:inputList4}]});
    console.log(Liability)
    //props.addCI(Asset); 
    props.addST(Liability); 
  };


  const show = () => {
    console.log(Asset);
    props.addCI(Asset); 
    //console.log(Asset[1]);
    //props.addCI(Asset[1]); 
     //console.log(JSON.stringify(props.balancedSheet.sheet))
  };
   
  const showLiability = () => {
    console.log(Liability);
    props.addST(Liability); 
    //console.log(Asset[1]);
    //props.addCI(Asset[1]); 
     //console.log(JSON.stringify(props.balancedSheet.sheet))
  };
   

  return (
    <div>
      <Helmet>
        <title>BalancedSheet</title>
        <meta name="description" content="Description of BalancedSheet" />
      </Helmet>

      <FormattedMessage {...messages.header} />

      <div className="App">
      <h3><a href="https://cluemediator.com">Clue Mediator</a></h3>
      <div>
      <Button
        onClick={() => setOpen(!open)}
        aria-controls="example-collapse-text"
        aria-expanded={open}
      >
        click
      </Button>
      <Collapse in={open}>
        <div id="example-collapse-text">
        {inputList.map((x, i) => {
        return (
          <div className="box">
        
            <input
              name="firstName"
              placeholder="Enter First Name"
              value={x.firstName}
              onChange={e => handleInputChange(e, i)}
            />
            <input
              className="ml10"
              name="lastName"
              placeholder="Enter Last Name"
              value={x.lastName}
              onChange={e => handleInputChange(e, i)}
            />
            <div className="btn-box">
             
              {inputList.length - 1 === i && <button onClick={handleAddClick}>Add</button>}
              <button onClick={handleAddCI}>Save</button>
              <button onClick={show}>Show</button>
            </div>
          </div>
        );
      })}
        </div>
      </Collapse>
      </div>
      <div>
      <Button
        onClick={() => setOpen(!open)}
        aria-controls="example-collapse-text"
        aria-expanded={open}
      >
        click
      </Button>
      <Collapse in={open}>
        <div id="example-collapse-text">
        {inputList2.map((x, i) => {
        return (
          <div className="box">
        
            <input
              name="firstName"
              placeholder="Enter First Name"
              value={x.firstName}
              onChange={e => handleInputChange2(e, i)}
            />
            <input
              className="ml10"
              name="lastName"
              placeholder="Enter Last Name"
              value={x.lastName}
              onChange={e => handleInputChange2(e, i)}
            />
            <div className="btn-box">
             
              {inputList2.length - 1 === i && <button onClick={handleAddClick}>Add</button>}
              <button onClick={handleAddLA}>Save</button>
              <button onClick={show}>Show</button>
            </div>
          </div>
        );
      })}
        </div>
        </Collapse>
      </div>


      <div>
      <Button
        onClick={() => setOpen(!open)}
        aria-controls="example-collapse-text"
        aria-expanded={open}
      >
        click
      </Button>
      <Collapse in={open}>
        <div id="example-collapse-text">
        {inputList4.map((x, i) => {
        return (
          <div className="box">
        
            <input
              name="firstName"
              placeholder="Enter First Name"
              value={x.firstName}
              onChange={e => handleInputChange4(e, i)}
            />
            <input
              className="ml10"
              name="lastName"
              placeholder="Enter Last Name"
              value={x.lastName}
              onChange={e => handleInputChange4(e, i)}
            />
            <div className="btn-box">
             
              {inputList4.length - 1 === i && <button onClick={handleAddClick4}>Add</button>}
              <button onClick={handleAddST}>Save</button>
              <button onClick={showLiability}>Show</button>
            </div>
          </div>
        );
      })}
        </div>
        </Collapse>
      </div>
      

      <div style={{ marginTop: 20 }}>{JSON.stringify(inputList4)}</div>
      <div style={{ marginTop: 20 }}>{JSON.stringify(inputList2)}</div>
     
      <div style={{ marginTop: 20 }}>{JSON.stringify(props.balancedSheet)}</div> 

     
      <div style={{ marginTop: 20 }}>{JSON.stringify(inputList)}</div>
      
      <div style={{ marginTop: 20 }}>{JSON.stringify(LA)}</div>
      <div style={{ marginTop: 40 }}>{JSON.stringify(Asset)}</div>
      
    </div>

      





    </div>
  );
}

BalancedSheet.propTypes = {
  dispatch: PropTypes.func.isRequired,
  addCI: PropTypes.func,  
  addST: PropTypes.func,  
};

const mapStateToProps = createStructuredSelector({
  balancedSheet: makeSelectBalancedSheet(),
});

function mapDispatchToProps(dispatch) {
  return {
    dispatch,
    addCI:(data)=>{dispatch(addCI(data))},
    addST:(data)=>{dispatch(addST(data))},

  };
}

const withConnect = connect(
  mapStateToProps,
  mapDispatchToProps,
);

export default compose(
  withConnect,
  memo,
)(BalancedSheet);


/*
 {inputList.map((x, i) => {
        return (
          <div className="box">
        
            <input
              name="firstName"
              placeholder="Enter First Name"
              value={x.firstName}
              onChange={e => handleInputChange(e, i)}
            />
            <input
              className="ml10"
              name="lastName"
              placeholder="Enter Last Name"
              value={x.lastName}
              onChange={e => handleInputChange(e, i)}
            />
            <div className="btn-box">
              {inputList.length !== 1 && <button
                className="mr10"
                onClick={() => handleRemoveClick(i)}>Remove</button>}
              {inputList.length - 1 === i && <button onClick={handleAddClick}>Add</button>}
            </div>
          </div>
        );
      })}
      */
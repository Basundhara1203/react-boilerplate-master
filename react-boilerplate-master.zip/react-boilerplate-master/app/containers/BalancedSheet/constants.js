/*
 *
 * BalancedSheet constants
 *
 */

export const DEFAULT_ACTION = 'app/BalancedSheet/DEFAULT_ACTION';

/*
 *
 * LoginPage actions
 *
 */

import { DEFAULT_ACTION } from './constants';

export function defaultAction() {
  return {
    type: DEFAULT_ACTION,
  };
}

export function loginEmp(data) {
  return {

    
      // event:e,
       type: 'LOGIN_EMP',
       data:data

  }
}

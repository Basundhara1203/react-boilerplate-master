/**
 *
 * LoginPage
 *
 */

import React, { memo ,useState} from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { Helmet } from 'react-helmet';
import { FormattedMessage } from 'react-intl';
import { createStructuredSelector } from 'reselect';
import { compose } from 'redux';
import {loginEmp} from './actions'
import {useHistory} from 'react-router-dom'
import Employee from 'containers/Employee/Loadable';
import history from 'utils/history'
import TextInput from 'components/LoginForm/Index';

import { useInjectSaga } from 'utils/injectSaga';
import { useInjectReducer } from 'utils/injectReducer';
import makeSelectLoginPage from './selectors';
import reducer from './reducer';
import saga from './saga';
import messages from './messages';

export function LoginPage(props) {
  const [state, setState] = useState({username:"", password:"" });
  const handleChange=(e)=>{
    const {name,value}= e.target;
    setState(preState=>({
      ...preState,
      [name]:value
    }));
  };
  useInjectReducer({ key: 'loginPage', reducer });
  useInjectSaga({ key: 'loginPage', saga });



  //const history=useHistory();

  const login = () => {  
   // if (state.employeeName && state.employeeDepartment && !state.id) {  
      const newEmployee = {  
       // id:state.id,  
        username: state.username,  
        password: state.password,  
      };  
  
      //props.addEmployee(newEmployee);  

      props.loginEmp(newEmployee);  
      console.log("login",localStorage.getItem("Token"))
      /*
      if(localStorage.getItem("Token")==null){alert("username and email is incorrect" } else{history.push("/Employee",{from:"LoginPage"})}
      */
    }

  return (
    <div>
     
        <title>LoginPage</title> <p className="App-intro">  
          <div className="leftsection">  
          <h5><center>LoginPage</center></h5>
          <TextInput handleChange={handleChange} login={login} state={state}/>
            
          </div> 
          </p>
      
     
    </div>
  );
}

LoginPage.propTypes = {
  dispatch: PropTypes.func.isRequired,
  loginEmp: PropTypes.any,
};

const mapStateToProps = createStructuredSelector({
  loginPage: makeSelectLoginPage(),
});

function mapDispatchToProps(dispatch) {
  return {
    dispatch,
    loginEmp:(data)=>{dispatch(loginEmp(data))},
  };
}

const withConnect = connect(
  mapStateToProps,
  mapDispatchToProps,
);

export default compose(
  withConnect,
  memo,
)(LoginPage);


/*
  UserName : <input onChange={(e)=>handleChange(e)}  name="username" value={state.username} type="text" placeholder="username" /> <br />  
           password :  <input onChange={(e)=>handleChange(e)}  name="password" value={state.password} type="text" placeholder="password" /><br />  
            <button onClick={login}>LOGIN</button>

*/
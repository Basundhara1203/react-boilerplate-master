import React from "react";
import {Container, Col, Row,Table ,Form} from 'react-bootstrap';
//import '../AddInput/node_modules/bootstrap/dist/css/bootstrap.css';
import 'bootstrap/dist/css/bootstrap.css';
import Navbar from 'react-bootstrap/Navbar'
import Nav from 'react-bootstrap/Nav'
import Button from 'react-bootstrap/Button'
//import { call, put, takeEvery,takeLatest } from 'redux-saga/effects'
import history from 'utils/history'
//import auth from "./auth";
  //const history=useHistory();

  const employee = () => {  
    // if (state.employeeName && state.employeeDepartment && !state.id) {  
        history.push("/Employees",{from:"LoginPage"})
       };  

       const worth = () => {  
        // if (state.employeeName && state.employeeDepartment && !state.id) {  
            history.push("/Worth",{from:"LoginPage"})
           }; 
           const  onLogout = () => {  
   
            localStorage.removeItem("Token")
            history.push("/LoginPage")
        
           }
       
export const Choice = () => {
  return (
    <div>
     <Navbar bg="dark" variant="dark">
    <Navbar.Brand href="#home">Dashboard</Navbar.Brand>
    <Nav className="mr-auto">
      
      <Nav.Link href="/Worth">NetWorth</Nav.Link>
      <Nav.Link href="/Employees">Employees</Nav.Link>
     
    </Nav>
    <Form inline>
     
      <Button  onClick={() => 
            onLogout()
          }
       >Log Out</Button>
    </Form>
  </Navbar>
     
    
    </div>
  );
};

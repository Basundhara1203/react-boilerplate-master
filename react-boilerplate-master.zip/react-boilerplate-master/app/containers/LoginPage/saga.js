// import { take, call, put, select } from 'redux-saga/effects';

// Individual exports for testing
import React from "react";
import { call, put, takeEvery,takeLatest } from 'redux-saga/effects'
import history from 'utils/history'
import {Choice} from './Choice'
// Individual exports for testing
import { all } from 'redux-saga/effects'
import request from 'utils/request';
function* LoginEmp (action) {
  const url=`http://localhost:3001/Employee/login`
  try {
     const subscriber  = action.data;
  console.log(subscriber);
     const subscriberDetails=yield call(()=>request(url,{
        method:"POST",
        headers:{
           'Accept':'application/json',
          // 'authentication':`bearerToken eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VyIjp7ImlkIjoxLCJ1c2VybmFtZSI6ImpvaG4iLCJlbWFpbCI6ImpvaG5AZ21haWwuY29tIn0sImlhdCI6MTYwNTk1MTcxM30.kcuDE8JFrn8VUkhmTrtjRvhnxTVOYYbUa8bWjq8Hvlg`,
           'Content-Type':'application/json'
         },
           body:JSON.stringify(subscriber)
        }
     ))
    console.log("subc",subscriberDetails)
   
    //console.log("subc",subscriberDetails.token)
 
    if(subscriberDetails==null){
     alert("username and email is incorrect");
     }
   
    
    
    
    
else{
  localStorage.setItem("Token", subscriberDetails.token);
  console.log((localStorage.getItem("Token")));
  history.push("/Choice",{from:"LoginPage"})
 // history.push("/Employee",{from:"LoginPage"})
}
    // const subscriberDetails = yield axios.post("http://localhost:3001/Employee/add", subscriber).then(response => response.data);
    // yield put({ type: 'LOGIN_SUCCESS', data: subscriberDetails });
   } catch (error) {
     //yield put({ type: 'CREATE_SUBSCRIBER_FAILED', error });
     alert(error+"  Enter Login Details Correctly")
   }
}


function* watchLoginUserRequest(){
  yield takeEvery('LOGIN_EMP', LoginEmp);
}


export default function* loginPageSaga() {
  // See example in containers/HomePage/saga.js

  yield all([
    watchLoginUserRequest()
  ])}
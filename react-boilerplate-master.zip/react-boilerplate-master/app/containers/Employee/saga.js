// import { take, call, put, select } from 'redux-saga/effects';

// Individual exports for testing
//export default function* employeeSaga() {
  // See example in containers/HomePage/saga.js
//}
// import { take, call, put, select } from 'redux-saga/effects';

import { call, put, takeEvery,takeLatest } from 'redux-saga/effects'
import axios from 'axios'
// Individual exports for testing
import {CREATE_SUBSCRIBER,DETAIL_EMPLOYEE,EDIT_EMPLOYEE,DELETE_EMPLOYEEE} from './constants'
import { all } from 'redux-saga/effects'
import request from 'utils/request';
import {
   getUsersFailed,getUsersSuccess,getUsers,getUsersEditSuccess,createUserSuccess,createUserFailed
} from './actions'
import * as api from './api/data'  ;


const token=localStorage.getItem("Token");
const header={
   'Accept':'application/json',
   'authentication':`bearerToken`+` `+`${token}`,
   'Content-Type':'application/json'
 }

function* fetchEmployees(action) {
   const requestURL="http://localhost:3001/Employee/list"
  try {
      const employees =  yield yield call(()=>request((requestURL),{
         method:"GET",
         headers:header}));
      const users=employees
      yield put(getUsersSuccess(users) );
   } catch (e) {
      //yield put({type: 'GET_EMPLOYEES_FAILED', message: e.message});
      yield put(getUsersFailed(e));
   }
}


function* requestSaga() {
   // yield takeEvery('GET_EMPLOYEES_REQUESTED', fetchEmployees);
   yield takeEvery(getUsers, fetchEmployees);
 }

function* EditEmployee(action) {
   try {
     const { data } = action;
     console.log(data.id);
     const token=localStorage.getItem("Token");
     if(token==null){
        alert("You are not logged in");
     }
     else{
     const subscriberDetails=yield call(()=>request((`http://localhost:3001/Employee/update/${data.id}`),{
        method:"PATCH",
        headers:{
         'Accept':'application/json',
         //'authentication':`bearerToken`+` `+`${action.token}`,
         'authentication':`bearerToken`+` `+`${token}`,
//'authentication':`bearerToken eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VyIjp7ImlkIjoxLCJ1c2VybmFtZSI6ImpvaG4iLCJlbWFpbCI6ImpvaG5AZ21haWwuY29tIn0sImlhdCI6MTYwNTk1MTcxM30.kcuDE8JFrn8VUkhmTrtjRvhnxTVOYYbUa8bWjq8Hvlg`,
         'Content-Type':'application/json'
       },
           body:JSON.stringify(data)
        }
     ))
    // const subscriberDetails = yield axios.post("http://localhost:3001/Employee/add", subscriber).then(response => response.data);
    // yield put({ type: 'EDDIT_SUBSCRIBER_SUCCESS', users: subscriberDetails });
     yield put(getUsers());
      }
   } catch (error) {
    // yield put({ type: 'CREATE_SUBSCRIBER_FAILED', error });
   }
 }

 function* watchEDITUserRequest(){
   yield takeLatest(EDIT_EMPLOYEE, EditEmployee);
}



function* createEmp(action) {
   try {
     const subscriber  = action.body;
     console.log(subscriber);
    // localStorage.removeItem("Token");
     console.log(localStorage.getItem("Token"));
     const token=localStorage.getItem("Token");
     if(token==null){
        alert("You are not logged in");
     }
     else{
     const subscriberDetails=yield call(()=>request(("http://localhost:3001/Employee/add"),{
        method:"POST",
        headers:{
           'Accept':'application/json',
           //'authentication':`bearerToken`+` `+`${action.token}`,
           'authentication':`bearerToken`+` `+`${token}`,
//'authentication':`bearerToken eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VyIjp7ImlkIjoxLCJ1c2VybmFtZSI6ImpvaG4iLCJlbWFpbCI6ImpvaG5AZ21haWwuY29tIn0sImlhdCI6MTYwNTk1MTcxM30.kcuDE8JFrn8VUkhmTrtjRvhnxTVOYYbUa8bWjq8Hvlg`,
           'Content-Type':'application/json'
         },
           body:JSON.stringify(subscriber)
        }
     ))
    // const subscriberDetails = yield axios.post("http://localhost:3001/Employee/add", subscriber).then(response => response.data);
    // yield put({ type: 'CREATE_SUBSCRIBER_SUCCESS', data: subscriberDetails });
    yield put(createUserSuccess(subscriberDetails));
   
      }
   } catch (error) {

     alert(error+"  Enter Employee Details Correctly")

     yield put(createUserFailed(error));
   }
 }
 



 function* watchCreateUserRequest(){
   yield takeLatest(CREATE_SUBSCRIBER, createEmp);
}


function* detailsEmp (action) {
   const url=`http://localhost:3001/Employee/data/${action.id}`
   console.log("url",url)

   try {

      const token=localStorage.getItem("Token");
     if(token==null){
        alert("You are not logged in");
     }
     else{

         const users= yield call(()=>request(url,{
            method:"GET",
            headers:{
               'Accept':'application/json',
               //'authentication':`bearerToken`+` `+`${action.token}`,
               'authentication':`bearerToken`+` `+`${token}`,
    //'authentication':`bearerToken eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VyIjp7ImlkIjoxLCJ1c2VybmFtZSI6ImpvaG4iLCJlbWFpbCI6ImpvaG5AZ21haWwuY29tIn0sImlhdCI6MTYwNTk1MTcxM30.kcuDE8JFrn8VUkhmTrtjRvhnxTVOYYbUa8bWjq8Hvlg`,
               'Content-Type':'application/json'
             },
             }))
         console.log("yes",users);
         // .then(response => response.data); // Refer sample to api calls in remote.js file
         yield put(getUsersEditSuccess(users)) // pass in the id you updated and the newData returned from the API
         /// Other things can go here depending on what you want
         }
      }
    catch (e) {
     // Handle your errors here
   }
 }


 function* watchDetailUserRequest(){
   yield takeEvery(DETAIL_EMPLOYEE, detailsEmp);
}




function* deleteEmp (action) {
   const url=`http://localhost:3001/Employee/delete/${action.id}`
   console.log("url",url)
   try {
      const token=localStorage.getItem("Token");
     if(token==null){
        alert("You are not logged in");
     }
     else{
            yield call(()=>request(url,{method:"DELETE",
            headers:{
               'Accept':'application/json',
               //'authentication':`bearerToken`+` `+`${action.token}`,
               'authentication':`bearerToken`+` `+`${token}`,
    //'authentication':`bearerToken eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VyIjp7ImlkIjoxLCJ1c2VybmFtZSI6ImpvaG4iLCJlbWFpbCI6ImpvaG5AZ21haWwuY29tIn0sImlhdCI6MTYwNTk1MTcxM30.kcuDE8JFrn8VUkhmTrtjRvhnxTVOYYbUa8bWjq8Hvlg`,
               'Content-Type':'application/json'
             }
            }))
            
            // .then(response => response.data); // Refer sample to api calls in remote.js file
            yield put(getUsers()) // pass in the id you updated and the newData returned from the API
            
         }
      }
    catch (e) {
     // Handle your errors here
   }
 }


 function* watchDeleteUserRequest(){
   yield takeEvery(DELETE_EMPLOYEEE, deleteEmp);
}

//export default requestSaga;

function* LoginEmp (action) {
   const url=`http://localhost:3001/api/login`
   try {
      const { subscriber } = action.data;
      const subscriberDetails=yield call(()=>request(url,{
         method:"POST",
         headers:{
            'Accept':'application/json',
           // 'authentication':`bearerToken eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VyIjp7ImlkIjoxLCJ1c2VybmFtZSI6ImpvaG4iLCJlbWFpbCI6ImpvaG5AZ21haWwuY29tIn0sImlhdCI6MTYwNTk1MTcxM30.kcuDE8JFrn8VUkhmTrtjRvhnxTVOYYbUa8bWjq8Hvlg`,
            'Content-Type':'application/json'
          },
            body:JSON.stringify(subscriber)
         }
      ))
     // const subscriberDetails = yield axios.post("http://localhost:3001/Employee/add", subscriber).then(response => response.data);
      yield put({ type: 'LOGIN_SUCCESS', data: subscriberDetails });
    } catch (error) {
      //yield put({ type: 'CREATE_SUBSCRIBER_FAILED', error });
    }
 }


 function* watchLoginUserRequest(){
   yield takeEvery('LOGIN_EMPLOYEEE', LoginEmp);
}

export default function* employeeSaga() {
  // See example in containers/HomePage/saga.js
 
  
    yield all([
      requestSaga(),
      watchLoginUserRequest(),
      watchCreateUserRequest(),
      watchDeleteUserRequest(),
      watchDetailUserRequest(),
      watchEDITUserRequest()
    ])
  
  
}

/*

export function* subscriberSaga() {
   yield all( [
       takeLatest(types.CREATE_SUBSCRIBER, createSubscriber),
       takeLatest(types.UPDATE_SUBSCRIBER, updateSubscriber),
   ])
}
*/


/*


function* createUser({payload}){
   try{
       yield call(api.addEmployee, {
          payload:payload
       });

       yield call(fetchEmployees);

   }catch(e){
       yield put(usersError({
           error: 'An error occurred when trying to create the user'
       }));
   }
}
/*
function* watchCreateUserRequest(){
   yield takeLatest('ADD_EMPLOYEE', createUser);
}

*/






/*
function* addEmployees(action) {
   const requestURL="http://localhost:3001/Employee/add"
  try {
      const employees =  yield call(requestURL,{
         method:"POST",
         headers:{
            'Accept':'application/json',
            'Content-Type':'application/json'
         },
         body:JSON.stringify(action.payload)

      });
         //axios.get, "http://dummy.restapiexample.com/api/v1/employees");
      yield put()
      
      const users=employees
      //.data;
      
      console.log("inusersaga",users)
      console.log("in users saga ...rs",employees)



      //yield put({type: 'GET_EMPLOYEES_SUCCESS', users: users});
      yield put(getUsersSuccess(users) );

      //console.log("inusersaga2"+data)

   } catch (e) {
      //yield put({type: 'GET_EMPLOYEES_FAILED', message: e.message});
      yield put(getUsersFailed(e));
   }
}





















*/

/*

function* deleteEmp ({ id }) {
   try {
     // Ensure that your API returns the data of the updated todo
     const newData = yield axios.delete(`http://localhost:3001/Employee/delete/${id}`,id)
     .then(response => response.data); // Refer sample to api calls in remote.js file
     yield put({type:'DELETE_EMPLOYEE',id:newData}) // pass in the id you updated and the newData returned from the API
     /// Other things can go here depending on what you want
   }
    catch (e) {
     // Handle your errors here
   }
 }


 function* watchDeleteUserRequest(){
   yield takeLatest('DELETE_EMPLOYEEE', deleteEmp);
}



*/
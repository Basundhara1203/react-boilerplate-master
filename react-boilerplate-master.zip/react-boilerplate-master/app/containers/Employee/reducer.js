/*
 *
 * Employee reducer
 *
 */
/*
import produce from 'immer';
import { DEFAULT_ACTION } from './constants';

export const initialState = {};

/* eslint-disable default-case, no-param-reassign */ 








/*

import produce from 'immer';
//import { DEFAULT_ACTION } from './constants';

 export const initialState = {  
  employees: [  
      { id: 1, employeeName: "Employee 1", employeeDepartment: ".NET Team" },  
      { id: 2, employeeName: "Employee 2", employeeDepartment: "Mobile Team" },  
      { id: 3, employeeName: "Employee 3", employeeDepartment: "Design Team" }  
  ]  
}; */

/* eslint-disable default-case, no-param-reassign */

//const employeeReducer = (state = initialState, action) =>
//  produce(state, (/* draft */) => {
 /*   switch (action.type) {  
      case 'GET_EMPLOYEE':  
          return {  
              ...state  
          }; 
          case 'ADD_EMPLOYEE':    
            return {    
                ...state,    
                employees: state.employees.concat(action.payload)    
            };    
        case 'EDIT_EMPLOYEE':    
            return {    
                ...state,    
                employees: state.employees.map(    
                    (content, i) => content.id === action.payload.id ? {...content, employeeName : action.payload.employeeName ,  employeeDepartment : action.payload.employeeDepartment }    
                                            : content)    
            };    
        case 'DELETE_EMPLOYEE':    
            return {    
                ...state,    
                employees: state.employees.filter(item => item.id !== action.payload)    
            };    
        
      default:  
          return state;  
  
    }
    
  });

export default employeeReducer;

*/

import produce from 'immer';
import * as type from './constants';
import { combineReducers } from 'redux';



export const initialState =({
  users: [],
  isloading: false,
  error: null,
  details:[],
  data:null
});

/* eslint-disable default-case, no-param-reassign */
export  function  employeeReducer(state = initialState, action) {
    switch (action.type) {
     
        case type.GET_EMPLOYEES_REQUESTED:
        
          return {
            ...state,
            isloading: true,
           
          }
        case type.GET_EMPLOYEES_SUCCESS:
            //console.log("reducer",action.users)
         return {
            ...state,
            isloading: false,
            users: action.users,
            
            
          }

          case 'ADD_EMPLOYEE':    
            return {    
                ...state,    
               // employees: state.employees.concat(action.payload)    
               isloading:false,
               users:action.payload,
            }; 

            case 'DELETE_EMPLOYEE':    
            return {    
                ...state,    
               id:action.payload,  
            }; 
        
        case type.GET_EMPLOYEES_FAILED:
          return {
            ...state,
            isloading: false,
            error: action.message,
          }

          case 'GET_EDIT_EMPLOYEES_SUCCESS':
            alert( JSON.stringify(action.users,null
      
              ,2));
          
          
          return {
              ...state,
              isloading: false,
              details: action.users,
             
            }
 
            case 'LOGIN_SUCCESS':
              alert("Logged in");
            return { ...state, isloading: false, data: action.data };

            
          case 'EDDIT_SUBSCRIBER_SUCCESS':
            return { ...state, isloading: false, users: action.users };


          case 'CREATE_SUBSCRIBER_SUCCESS':
            return { ...state, isloading: false, subscriberDetails: action.users };
          case 'CREATE_USER_FAILED':
            return { ...state, isloading: false, error: action.error };


            case 'CREATE_USER_SUCCESS':
              
                return { ...state, isloading: false, users: action.users };

            case 'onLogout':
              alert("Logged out");
              return{
                ...state,data:null
              }

        default:
          return state
    }
  };
  //const employeeReducer = combineReducers({
  // users: users,});

export default employeeReducer;
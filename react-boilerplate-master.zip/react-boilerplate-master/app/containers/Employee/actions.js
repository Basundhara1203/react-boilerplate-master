/*
 *
 * Employee actions
 *
 */


 /*
 *
 * EmployeeTable actions
 *
 */

import * as type from './constants';
import history  from 'utils/history'








export function getUsers() {

 
  return {

    
      // event:e,
       type: type.GET_EMPLOYEES_REQUESTED,
  }
  
}


export function getUsersFailed(e) {
  return {


         type: type.GET_EMPLOYEES_FAILED,
         message: e.message

  }
}


export function getUsersSuccess(users) {
  return {


    type: type.GET_EMPLOYEES_SUCCESS,
    users:users

  }
}
export function addEmployee(data) {  
  
      return {  
          type: 'ADD_EMPLOYEE',  
          payload: data  
      };  
  }  


export function getEmployee() {  
  return dispatch => {  
      return dispatch({  
          type: 'GET_EMPLOYEE'  
      });  
  }  
}; 
/*
export function addEmployee(data) {  
  return dispatch => {  
      return dispatch({  
          type: 'ADD_EMPLOYEE',  
          payload: data  
      });  
  }  
};  
*/

export function editEmployee(data) {  
 // return dispatch => {  
      return {
      //dispatch({  
          type: 'EDIT_EMPLOYEE',  data
         // payload: data  
      };  
  
};  





export function deleteEmployee(employeeId) {  
  return dispatch => {  
      return dispatch({  
          type: 'DELETE_EMPLOYEEE',  
           id:employeeId  
      });  
  }  
}; 



export function editEmp(employeeId) {  
  return dispatch => {  
      return dispatch({  
          type: 'DETAIL_EMPLOYEE',  
           id:employeeId  
      });  
  }  
}; 



export function getUsersEditSuccess(users) {
  return {


    type: 'GET_EDIT_EMPLOYEES_SUCCESS',
    users:users

  }
}

export function createUserSuccess(subscriber) {
  return { type: 'CREATE_USER_SUCCESS', 
            body:subscriber ,
            //token:token
};

}
export function createUserFailed(error) {
  return { type: 'CREATE_USER_Failed', 
            error:error 
            //token:token
    };


}


export function createSubscriber(subscriber) {
  return { type: 'CREATE_SUBSCRIBER', 
            body:subscriber ,
            //token:token
    };
}
export function loginEmployee(data) {

  return {

       type: 'LOGIN_EMPLOYEEE',
       data:data

  }
 }






/*

export const onLogout =(e)=>{
  return{
      type:'onLogout',

      event:e
 
  }

}

export const usersError = ({error}) => ({
  type: 'USERS_ERROR',
  payload: {
      error
  }
});
/*
export const createUserRequest = (data) => ({
  type: Types.CREATE_USER_REQUEST,
  payload: {
      firstName,
      lastName
  }
});
*/

 




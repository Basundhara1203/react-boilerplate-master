export const createPost = ({post}) => {
   // console.log("api call ->", post)
    //let randomId = Math.random()*100;
    return axios.post('http://localhost:4000/posts',{"id":randomId, "msg": post + randomId})
}

export const addEmployee = ({newEmployee}) => {
    return axios.post('http://localhost:3001/Employee/add', {
        newEmployee
    });
};
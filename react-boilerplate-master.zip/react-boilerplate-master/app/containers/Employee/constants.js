/*
 *
 * Employee constants
 *
 */

 
export const DEFAULT_ACTION = 'app/Registration/DEFAULT_ACTION';
export const SET_FORMVALUES="SET_FORMVALUES";
export const SUBMIT_FORM="SUBMIT_FORM";
export const onReset="onReset";
//export const DEFAULT_ACTION = 'app/EmployeeTable/DEFAULT_ACTION';

export const GET_EMPLOYEES_REQUESTED = 'GET_EMPLOYEES_REQUESTED';
export const GET_EMPLOYEES_SUCCESS = 'GET_EMPLOYEES_SUCCESS';
export const GET_EMPLOYEES_FAILED = 'GET_EMPLOYEES_FAILED';

//export const DEFAULT_ACTION = 'app/Employee/DEFAULT_ACTION';
export const CREATE_SUBSCRIBER='CREATE_SUBSCRIBER'
export const DETAIL_EMPLOYEE='DETAIL_EMPLOYEE'
export const EDIT_EMPLOYEE='EDIT_EMPLOYEE'
export const DELETE_EMPLOYEEE='DELETE_EMPLOYEEE'
//export const 
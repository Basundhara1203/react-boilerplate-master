/**
 *
 * Employee
 *
 */

 /*const [id, setid] = useState(0);
    const [employeeName, setEmployeeName] = useState("");
    const [employeeDepartment, setEmployeeDepartment] = useState("");
    */
/**
 *
 * Crudapplication
 *
 */
//import React, { memo } from 'react';
import {Container, Col, Row } from 'react-bootstrap';
//import PropTypes from 'prop-types';
//import { connect } from 'react-redux';
//import { Helmet } from 'react-helmet';
//import { FormattedMessage } from 'react-intl';
//import { createStructuredSelector } from 'reselect';
//import { compose } from 'redux';
import {actionsub,actionset,actionreset} from './actions'
//import TextInput from './component/TextInput';
import DateInput from '../../components/DateInput/Index';
import SelectInput from '../../components/SelectInput/Index';
import RadioInput from '../../components/RadioInput/Index';
import TextareaInput from '../../components/TextareaInput/Index';
import {FormHead } from '../../components/FormHeader/index';
import Wrapper from  '../../components/TableDiv/Wrapper';
import {useHistory} from 'react-router-dom'


//import './style.css';


//import { useInjectReducer } from 'utils/injectReducer';
//import makeSelectRegistration from './selectors';
//import reducer from './reducer';
//import messages from './messages';
//import SignInFormDesign from './SignInFormDesign';
import React, { memo ,useState} from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { Helmet } from 'react-helmet';
import { FormattedMessage } from 'react-intl';
import { createStructuredSelector } from 'reselect';
import { compose } from 'redux';
import  { useEffect } from 'react';
import saga from './saga';
import history from 'utils/history'
import TableComp from '../../components/TableComp/Index';
import TextInput from '../../components/FormDiv/Index';
import {Choice} from 'containers/LoginPage/Choice';

import {Head} from '../../components/TableCompHead/index';
import {getEmployee,getUsers,onLogout,addEmployee, editEmployee,editEmp,loginEmployee, deleteEmployee,createSubscriber} from './actions';
//import {addEmployee} from './api/data'
import { useSelector, useDispatch } from 'react-redux';
import { useInjectSaga } from 'utils/injectSaga';
import { useInjectReducer } from 'utils/injectReducer';
import makeSelectEmployee from './selectors';
  //makeSelectCrudapperrorapplication} from './selectors';
import reducer from './reducer';
import messages from './messages';

export function Employee(
  
 props
  ) {
    const [state, setState] = useState({id:0, employeeName:"", employeeDepartment:"" });
    const handleChange=(e)=>{
      const {name,value}= e.target;
      setState(preState=>({
        ...preState,
        [name]:value
      }));
    };
    useInjectReducer({ key: 'employee', reducer });
    useInjectSaga({ key: 'employee', saga });
 
  const dispatch = useDispatch();
    useEffect(() => {
      dispatch(getUsers());
      
    }, [])
    
   const submitData = () => {  
    if (state.employeeName && state.employeeDepartment && !state.id) {  
      const newEmployee = {  
        id:(Math.floor(Math.random() * 99 + 100)).toString(),  
        employeeName: state.employeeName,  
        employeeDepartment: state.employeeDepartment,  
      };  
  
      //props.addEmployee(newEmployee);  

      props.createSubscriber(newEmployee);
        //,props.employees.data.token);  
    }
    else if ( state.id && state.employeeName && state.employeeDepartment ) {  
      const updatedDetails = {  
        id: state.id,  
        employeeName: state.employeeName,  
        employeeDepartment: state.employeeDepartment,  
      };  
  
      props.editEmployee(updatedDetails);  
    } else {  
      alert('Enter Employee Details.');  
    }  
  
   clearEmployee();  
  }  
  
 const editDetails = (data) => {  
    setState({  
      id: data.id,  
      employeeName: data.employeeName,  
      employeeDepartment: data.employeeDepartment  
    })  
  }  
  
 const deleteEmployee = (id) => {  
    clearEmployee();  
    if (window.confirm("Are you sure?")) {  
      props.deleteEmployee(id);  
    }  
  }  


 
  const edit = (id) => {  
    
      props.editEmp(id); 
      console.log(props.employees) 
      console.log(props.employees.users)

      setTimeout(console.log(props.employee.details),2000);
  } 


const  clearEmployee = () => {  
   setState({  
      id: 0,  
      employeeName: "",  
      employeeDepartment: ""  
    });  
  }  
  
 
  const  onLogout = () => {  
   
    localStorage.removeItem("Token")
    history.push("/LoginPage",{from:"Employee"})

   }  

  //console.log(props.users)
  return (
  
  //console.log("o",props.users),
 // console.log(props.employees.users),
       <div className="App">  
        <header className="App-header">  
        <Choice/>
        <h1 className="App-title"><center>Employee Page</center></h1>  
        <TextInput handleChange={handleChange} submitData={submitData} state={state}/>  
        </header>  
        <p className="App-intro">  

          </p>
   
      <div>
      <Wrapper>
               <Head/>
              {props && props.employees &&  props.employees.users && props.employees.users.map((data) => {  
                return <TableComp key={data.id} data={data} edit={edit} editDetails={editDetails} deleteEmployee={deleteEmployee} />
                
               
                })}  


              
            </Wrapper>
         </div>
         </div>

    );  

}

Employee.propTypes = {
 // dispatch: PropTypes.func.isRequired,
 createSubscriber:PropTypes.any,
 editEmp:PropTypes.any,
 getUsers:PropTypes.any,
 getEmployee:PropTypes.any,
 employees: PropTypes.any,  
 addEmployee: PropTypes.func,  
    editEmployee: PropTypes.func,  
    deleteEmployee: PropTypes.func ,
    clearEmployee:PropTypes.func
   // getEmployee: PropTypes.func.isRequired  
 // ErrorSet:PropTypes.any
};

const mapStateToProps = createStructuredSelector({
  employees: makeSelectEmployee(),
 //error: makeSelectCrudapperrorapplication()
});

function mapDispatchToProps(dispatch) {
  return {
    dispatch,
    //getEmployee:()=>{dispatch(getEmployee)},
    loginEmployee:(data)=>{dispatch(loginEmployee(data))},
    addEmployee:(data)=>{dispatch(addEmployee(data))},
    createSubscriber:(data)=>{dispatch(createSubscriber(data))},
    deleteEmployee:(id)=>{dispatch(deleteEmployee(id))},
    editEmp:(id)=>{dispatch(editEmp(id))},
    editEmployee:(data)=>{dispatch(editEmployee(data))},
    //onLogout:(e)=>{dispatch(onLogout(e,"onLogout"))},
  };
}

const withConnect = connect(
  mapStateToProps,
 mapDispatchToProps,
);

export default compose(
  withConnect,
  memo,
)(Employee);

















/*



   return <tr key={(data.id)}>  
                    <td>{data.id}</td>  
                    <td>{data.employeeName}</td>  
                    <td>{data.employeeDepartment}</td>  
                    <td><button onClick={() =>edit(data.id)}>DETAILS</button> </td>
                    
                    <td><button onClick={() =>editDetails(data)}>EDIT</button></td>
                    <td><button onClick={() => deleteEmployee(data.id)}>DELETE</button> </td>
                  </tr>  


          <div className="leftsection">  
          Employee id : <input onChange={(e)=>handleChange(e)} name="id" value={state.id} type="text" placeholder="Employee id" /> <br />  
            Employee Name : <input onChange={(e)=>handleChange(e)}  name="employeeName" value={state.employeeName} type="text" placeholder="Employee Name" /> <br />  
            Employee Department :  <input onChange={(e)=>handleChange(e)}  name="employeeDepartment" value={state.employeeDepartment} type="text" placeholder="Employee Department" /><br />  
            {state.id ? <button onClick={submitData}>UPDATE</button> : <button onClick={submitData}>ADD</button>}    
          </div> 



import React, { memo } from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { Helmet } from 'react-helmet';
import { FormattedMessage } from 'react-intl';
import { createStructuredSelector } from 'reselect';
import { compose } from 'redux';

import { useInjectSaga } from 'utils/injectSaga';
import { useInjectReducer } from 'utils/injectReducer';
import makeSelectEmployee from './selectors';
import reducer from './reducer';
import saga from './saga';
import messages from './messages';

export function Employee() {
  useInjectReducer({ key: 'employee', reducer });
  useInjectSaga({ key: 'employee', saga });

  return (
    <div>
      <Helmet>
        <title>Employee</title>
        <meta name="description" content="Description of Employee" />
      </Helmet>
      <FormattedMessage {...messages.header} />
    </div>
  );
}

Employee.propTypes = {
  dispatch: PropTypes.func.isRequired,
};

const mapStateToProps = createStructuredSelector({
  employee: makeSelectEmployee(),
});

function mapDispatchToProps(dispatch) {
  return {
    dispatch,
  };
}

const withConnect = connect(
  mapStateToProps,
  mapDispatchToProps,
);

export default compose(
  withConnect,
  memo,
)(Employee);


 const loginEmp = () => {  
   
      //props.addEmployee(newEmployee);  


      const user = {
  
        id: 1,
    
        username: "john",
    
        email: "john@gmail.com"
    
      };

      props.loginEmployee(user);  
   
     console.log(props.employees.data)
  }  
  /*
  const login = () => {  
    
 history.push("/login")

    
}  


*/












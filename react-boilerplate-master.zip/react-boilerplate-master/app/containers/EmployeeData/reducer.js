/*
 *
 * EmployeeData reducer
 *
 */
import produce from 'immer';
import {List,Map} from 'immutable';
import { DEFAULT_ACTION } from './constants';
import * as type from './constants';
import{
  GET_EMPLOYEES_REQUESTED,
  GET_EMPLOYEES_SUCCESS,
  GET_EMPLOYEES_FAILED } from './constants';

//export const initialState = {};

export const initialState = Map({
  employees: new List(),
  //isloading: false,
  error: null,
});


/* eslint-disable default-case, no-param-reassign */
const employeeDataReducer = (state = initialState, action) =>
  produce(state, (/* draft */) => {
    switch (action.type) {
      case DEFAULT_ACTION:
        break;
        case GET_EMPLOYEES_SUCCESS:
        
          return   state.set('employees',action.employees);
           
            
          
        case GET_EMPLOYEES_FAILED:
          
         return  state.set('error',action.message);
        
          
        
       
        default:
          return state
    }
  });

export default employeeDataReducer;





  
  
  
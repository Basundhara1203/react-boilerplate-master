/*
 *
 * EmployeeData actions
 *
 */

import { DEFAULT_ACTION } from './constants';
import * as type from './constants';
import{
  GET_EMPLOYEES_REQUESTED,
  GET_EMPLOYEES_SUCCESS,
  GET_EMPLOYEES_FAILED } from './constants';

export const getEmployeesRequested=()=>({
 type:GET_EMPLOYEES_REQUESTED
});
 
export const getEmployeesSuccess=()=>({
  type:GET_EMPLOYEES_SUCCESS,
  employees
 });
 export const getEmployeesFailed=()=>({
  type:GET_EMPLOYEES_FAILED,
  message,
 });





export function getUsers() {
  
    return {



         type: type.GET_EMPLOYEES_REQUESTED,
    }
  }

export function defaultAction() {
  return {
    type: DEFAULT_ACTION,
  };
}

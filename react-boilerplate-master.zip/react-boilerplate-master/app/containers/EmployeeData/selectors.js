import { createSelector } from 'reselect';
import { initialState } from './reducer';

/**
 * Direct selector to the employeeData state domain
 */

const selectEmployeeDataDomain = state => state.employeeData || initialState;


const selectEmployees = (state) => state.get('employees');


const makeSelectEmployees = () => createSelector(
  selectEmployees,
  employeesState=>employeesState.get('employees'));

  
const makeSelectError = () => createSelector(
  selectEmployees,
  employeesState=>employeesState.get('error'));



/**
 * Other specific selectors
 */

/**
 * Default selector used by EmployeeData
 */

const makeSelectEmployeeData = () =>
  createSelector(
    selectEmployeeDataDomain,
    substate => substate,
  );

//export default makeSelectEmployeeData;
export { selectEmployeeDataDomain ,
selectEmployees,
makeSelectEmployees,
makeSelectError,

};

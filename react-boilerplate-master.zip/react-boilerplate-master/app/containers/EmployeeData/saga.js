 import { take, call, put, select } from 'redux-saga/effects';
 import axios from 'axios'
/*

function* fetchEmployees(action) {
  try {
      const employees =  yield call(axios.get, "http://dummy.restapiexample.com/api/v1/employees");
      
      
      const users=employees.data.data;
      
      console.log("inusersaga",users)
      console.log("in users saga ...rs",employees)



      yield put({type: 'GET_EMPLOYEES_SUCCESS', employees: employees});



   } catch (e) {
      yield put({type: 'GET_EMPLOYEES_FAILED', message: e.message});
   }
}
// Individual exports for testing
 function* rootSaga() {
  // See example in containers/HomePage/saga.js
  yield takeEvery('GET_EMPLOYEES_REQUESTED', fetchEmployees);
}
*/

export default function* employeeDataSaga() {
 // yield all([
 //   rootSaga(),
  //])
}
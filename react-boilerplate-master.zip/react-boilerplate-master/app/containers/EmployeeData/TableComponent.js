import React from 'react';
//import  './styles.css'
//import 'bootstrap/dist/css/bootstrap.min.css'
import {Table} from 'react-bootstrap'



const TableComponent = (props) => {
  return (
  <div className="t">

    <Table  striped bordered hover >
  
    
    <tbody>
      <tr>
      
     <td>{props.user.id}</td>
        <td className="f">{props.user.employee_name}</td>
        <td className="f">{props.user.employee_salary}</td>
        <td className="f">{props.user.employee_age}</td>
       


     
      </tr>
      </tbody>
    </Table>
    </div>
  )
}
export default  TableComponent;
 
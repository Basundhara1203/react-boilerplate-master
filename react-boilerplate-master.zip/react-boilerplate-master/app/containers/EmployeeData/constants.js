/*
 *
 * EmployeeData constants
 *
 */

export const DEFAULT_ACTION = 'app/EmployeeData/DEFAULT_ACTION';

export const GET_EMPLOYEES_REQUESTED = 'GET_EMPLOYEES_REQUESTED';
export const GET_EMPLOYEES_SUCCESS = 'GET_EMPLOYEES_SUCCESS';
export const GET_EMPLOYEES_FAILED = 'GET_EMPLOYEES_FAILED';

/**
 *
 * EmployeeData
 *
 */

import  { memo } from 'react';
import List from 'immutable';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { Helmet } from 'react-helmet';
import { FormattedMessage } from 'react-intl';
import { createStructuredSelector } from 'reselect';
import { compose } from 'redux';

import { useInjectSaga } from 'utils/injectSaga';
import { useInjectReducer } from 'utils/injectReducer';
import {selectEmployees,
  makeSelectEmployees,
  makeSelectError,} from './selectors';
  import {
    bindActionCreators} from 'redux';


import reducer from './reducer';
import saga from './saga';
import messages from './messages';
import React, { useEffect } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { getEmployeesRequested,getEmployeesSuccess ,getEmployeesFailed} from './actions';

//import 'bootstrap/dist/css/bootstrap.min.css'
import {Table} from 'react-bootstrap'
//import  './styles.css'
import TableComponent from './TableComponent';

export class EmployeeData extends React.Component
  {
    static propTypes = {
      getEmployeesRequested: PropTypes.func,
      employees:PropTypes.instanceOf(List),
      error:PropTypes.string
    }
    componentDidMount(){
      this.props.getEmployeesRequested();
    }
render(){
  const employees=this.props;
  return (
    <div>
        employees
    </div>
  )}

}



const mapStateToProps = createStructuredSelector({
 //employeeData: makeSelectEmployeeData(),
 employees: makeSelectEmployees(),
 error: makeSelectError(),
});

const mapDispatchToProps=dispatch =>{bindActionCreators({
  getEmployeesRequested,
  

},dispatch);

}

const withConnect = connect(
  mapStateToProps,
  mapDispatchToProps,
);
const withReducer= useInjectReducer({ key: 'employeeData', reducer });
const withSaga=useInjectSaga({ key: 'employeeData', saga });

const {employees}=this.props;

export default compose(
  withConnect,
  memo,
)(EmployeeData);

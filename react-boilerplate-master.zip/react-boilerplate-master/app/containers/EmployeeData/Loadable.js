/**
 *
 * Asynchronously loads the component for EmployeeData
 *
 */

import loadable from 'utils/loadable';

export default loadable(() => import('./index'));

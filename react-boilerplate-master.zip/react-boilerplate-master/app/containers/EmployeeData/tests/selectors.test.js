// import { selectEmployeeDataDomain } from '../selectors';

describe('selectEmployeeDataDomain', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(false);
  });
});

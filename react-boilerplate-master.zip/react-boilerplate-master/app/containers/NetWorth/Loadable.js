/**
 *
 * Asynchronously loads the component for NetWorth
 *
 */

import loadable from 'utils/loadable';

export default loadable(() => import('./index'));

/*
 *
 * NetWorth reducer
 *
 */
import produce from 'immer';
import { DEFAULT_ACTION } from './constants';

export const initialState = {sheets:[

  
    { id :"1",categories_name: "assets", data:  
                      [
                        {id :"101", categories_name: "cash and investments",data:[]},
                        {id :"102", categories_name: "Long-Term Assets",data:[]},
                        {id :"103", categories_name: "Property Assets",data:[]}
                      ]
                      },
                      { id :"2",categories_name: "Liabilities", data: 
                      [
                        {id :"201", categories_name: "Short-Term Liabilities",data:[]},
                        {id :"301", categories_name: "Mid and Long-Term Liabilities",data:[]}
                        ]
                      }
                    ]
}


/* eslint-disable default-case, no-param-reassign */
const netWorthReducer = (state = initialState, action) =>
  produce(state, (/* draft */) => {
    switch (action.type) {
      case DEFAULT_ACTION:
        break;



        case 'ADD_CI':    
         //state.sheet[0].data[0].data.concat(action.payload);
         //console.log(state)
        /* const content = state.sheet[0].templates[state.templateKey].items[
           state.itemKey
         ].properties.text.value =
           action.value;
   
         return { ...state, content };*/
        
         return {    
              ...state,
              sheets:[
                ...(state.sheets.map(sheet =>
                  sheet.id === action.s_id
                  ? { ...sheet, data:[
                        ...(sheet.data.map(d=>
                          d.id===action.d_id
                          ?{...d,data:action.payload
                          }:d))
                          

                  ]
                  
                  
                  
                  
                  }
                  : sheet
                ))


              ]
              /*
              data: {
                ...state.data,
                users: [
                  ...(state.data.users.map(user =>
                    user.id === action.payload.id
                    ? { ...user, value: action.payload.value }
                    : user
                  ))
                ]
              }
            };

           /*
            ...state,  
            b:sheet.concat({
              ...sheet,

            }
              
            )
               
             //sheet: state.sheet.data.data.concat(action.payload)   
            // sheet:action.payload 
           /* myPosts: {
             ...state.myPosts,
             isPending: true,*/
             //data:(action.payload)
            // draft[0].sheet[0].data[0].data=action.payload,                                                                                                                                                                                                                                                                                                                                                                                                                                                            
           //state.sheet[0].data[0].data.concat(action.payload)
         //  { 
            /* ...state.sheet,
             data:{
               ...state.sheet.data,
               data:(action.payload) ,
             }*/
           }
         case 'ADD_LA':
           return {    
            ...state,
            sheets:[
              ...(state.sheets.map(sheet =>
                sheet.id === action.s_id
                ? { ...sheet, data:[
                      ...(sheet.data.map(d=>
                        d.id===action.d_id
                        ?{...d,data:action.payload
                        }:d))

                ]
             }
                : sheet
              ))
            ]
          
         }



         case 'ADD_NR':
          return {    
           ...state,
           sheets:[
             ...(state.sheets.map(sheet =>
               sheet.id === action.s_id
               ? { ...sheet, data:[
                     ...(sheet.data.map(d=>
                       d.id===action.d_id
                       ?{...d,data:action.payload
                       }:d))

               ]
            }
               : sheet
             ))
           ]
         
        }



        case 'ADD_SL':
          return {    
           ...state,
           sheets:[
             ...(state.sheets.map(sheet =>
               sheet.id === action.s_id
               ? { ...sheet, data:[
                     ...(sheet.data.map(d=>
                       d.id===action.d_id
                       ?{...d,data:action.payload
                       }:d))

               ]
            }
               : sheet
             ))
           ]
         
        }

    }

  });






/*

  case SET_NAME:
  return {
    ...state,
    data: {
      ...state.data,
      users: [
        ...(state.data.users.map(user =>
          user.id === action.payload.id
          ? { ...user, value: action.payload.value }
          : user
        ))
      ]
    }
  };

  */
export default netWorthReducer;

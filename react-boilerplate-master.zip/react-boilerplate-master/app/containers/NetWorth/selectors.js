import { createSelector } from 'reselect';
import { initialState } from './reducer';

/**
 * Direct selector to the netWorth state domain
 */

const selectNetWorthDomain = state => state.netWorth || initialState;

/**
 * Other specific selectors
 */

/**
 * Default selector used by NetWorth
 */

const makeSelectNetWorth = () =>
  createSelector(
    selectNetWorthDomain,
    substate => substate,
  );

export default makeSelectNetWorth;
export { selectNetWorthDomain };

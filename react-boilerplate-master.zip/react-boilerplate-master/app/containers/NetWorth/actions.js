/*
 *
 * NetWorth actions
 *
 */

import { DEFAULT_ACTION } from './constants';

export function defaultAction() {
  return {
    type: DEFAULT_ACTION,
  };
}
export function addCI(data) {  
  return dispatch => {  
    console.log(data)

      return dispatch({  
          type: 'ADD_CI',  
          payload: data ,
          s_id:"1",
          d_id:"101" 
      });  
  }  
}; 

export function addLA(data) {  
  return dispatch => {  
    console.log(data)
    
      return dispatch({  
          type: 'ADD_CI',  
          payload: data ,
          s_id:"1",
          d_id:"102" 
      });  
  }  
}; 


export function addNR(data) {  
  return dispatch => {  
    console.log(data)
    
      return dispatch({  
          type: 'ADD_CI',  
          payload: data ,
          s_id:"1",
          d_id:"103" 
      });  
  }  
}; 


export function addSL(data) {  
  return dispatch => {  
    console.log(data)
    
      return dispatch({  
          type: 'ADD_CI',  
          payload: data ,
          s_id:"2",
          d_id:"201" 
      });  
  }  
}; 
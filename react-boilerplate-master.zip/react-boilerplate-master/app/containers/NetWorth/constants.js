/*
 *
 * NetWorth constants
 *
 */

export const DEFAULT_ACTION = 'app/NetWorth/DEFAULT_ACTION';

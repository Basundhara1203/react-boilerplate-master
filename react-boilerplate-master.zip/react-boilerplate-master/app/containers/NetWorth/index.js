/**
 *
 * NetWorth
 *
 */

import React, { memo,useState } from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { Helmet } from 'react-helmet';
import { FormattedMessage } from 'react-intl';
import { createStructuredSelector } from 'reselect';
import { compose } from 'redux';
import {addCI,addLA,addNR,addSL} from './actions';
import Button from 'react-bootstrap/Button'
import Collapse from 'react-bootstrap/Collapse'
import 'bootstrap/dist/css/bootstrap.css';

import { useInjectSaga } from 'utils/injectSaga';
import { useInjectReducer } from 'utils/injectReducer';
import makeSelectNetWorth from './selectors';
import reducer from './reducer';
import saga from './saga';
import messages from './messages';

export function NetWorth(props) {

  const [inputList5, setInputList5] = useState([{ id :(Math.floor(Math.random() * 99 + 100)).toString(), noteName: "", amt: "" }]);
  const [inputList4, setInputList4] = useState([{ id :(Math.floor(Math.random() * 99 + 100)).toString(), noteName: "", amt: "" }]);
  const [inputList3, setInputList3] = useState([{ id :(Math.floor(Math.random() * 99 + 100)).toString(), noteName: "", amt: "" }]);


  const [inputList2, setInputList2] = useState([{ id :(Math.floor(Math.random() * 99 + 100)).toString(), noteName: "", amt: "" }]);
  const [inputList, setInputList] = useState([{ id :(Math.floor(Math.random() * 99 + 100)).toString(), noteName: "", amt: "" }]);
  const [open, setOpen] = useState(false);
/*
    const [state, setState] = useState({id:0, noteName:"", amt:"" });
    const handleChangeFixed=(e)=>{
      const {name,value}= e.target;
      setState(preState=>({
        ...preState,
        [name]:value
      }));
    }
    */
  useInjectReducer({ key: 'netWorth', reducer });
  useInjectSaga({ key: 'netWorth', saga });




  const handleInputChange = (e, index) => {
   
    const { name, value } = e.target;
    const list = [...inputList];
   
    list[index][name] = value;
    setInputList(list);
  };

  const handleAddClick = () => {
    setInputList([...inputList, 
      { id :(Math.floor(Math.random() * 99 + 100)).toString(),
        noteName: "", amt: "" }]);
  };

  const handleAddCI = () => { 
    props.addCI(inputList); 
  };


  const handleInputChange2 = (e, index) => {
   
    const { name, value } = e.target;
    const list = [...inputList2];
   
    list[index][name] = value;
    setInputList2(list);
  };

  const handleAddClick2 = () => {
    setInputList2([...inputList2, 
      { id :(Math.floor(Math.random() * 99 + 100)).toString(),
        noteName: "", amt: "" }]);
  };

  const handleAddLA = () => { 
    props.addLA(inputList2); 
  };



  
  const handleInputChange3 = (e, index) => {
   
    const { name, value } = e.target;
    const list = [...inputList3];
   
    list[index][name] = value;
    setInputList3(list);
  };

  const handleAddClick3 = () => {
    setInputList3([...inputList3, 
      { id :(Math.floor(Math.random() * 99 + 100)).toString(),
        noteName: "", amt: "" }]);
  };

  const handleAddNR= () => { 
    props.addNR(inputList3); 
  };

    
  const handleInputChange4 = (e, index) => {
   
    const { name, value } = e.target;
    const list = [...inputList4];
   
    list[index][name] = value;
    setInputList4(list);
  };

  const handleAddClick4 = () => {
    setInputList4([...inputList4, 
      { id :(Math.floor(Math.random() * 99 + 100)).toString(),
        noteName: "", amt: "" }]);
  };

  const handleAddSL= () => { 
    props.addSL(inputList4); 
  };


  return (
    <div>
      <Helmet>
        <title>NetWorth</title>
        <meta name="description" content="Description of NetWorth" />
      </Helmet>
      <FormattedMessage {...messages.header} />
      <div className="App">
      <h3><a href="https://cluemediator.com">Clue Mediator</a></h3>

      <div>
      <Button
        onClick={() => setOpen(!open)}
        aria-controls="example-collapse-text"
        aria-expanded={open}
      >
        click
      </Button>
      <Collapse in={open}>
        <div id="example-collapse-text">
       {inputList.map((x, i) => {
        return (
          <div className="box">
        
            <input
              name="noteName"
              placeholder="Enter First Name"
              value={x.noteName}
              onChange={e => handleInputChange(e, i)}
            />
            <input
              className="ml10"
              name="amt"
              placeholder="Enter Last Name"
              value={x.amt}
              onChange={e => handleInputChange(e, i)}
            />
            <div className="btn-box">
             
              {inputList.length - 1 === i && <button onClick={handleAddClick}>Add</button>}
              <button onClick={handleAddCI}>Save</button>
             
            </div>
          </div>
        );
      })}
        </div>
      </Collapse>
      </div>


      <div>
      <Button
        onClick={() => setOpen(!open)}
        aria-controls="example-collapse-text"
        aria-expanded={open}
      >
        click
      </Button>
      <Collapse in={open}>
        <div id="example-collapse-text">
        {inputList2.map((x, i) => {
        return (
          <div className="box">
        
            <input
              name="noteName"
              placeholder="Enter First Name"
              value={x.noteName}
              onChange={e => handleInputChange2(e, i)}
            />
            <input
              className="ml10"
              name="amt"
              placeholder="Enter Last Name"
              value={x.amt}
              onChange={e => handleInputChange2(e, i)}
            />
            <div className="btn-box">
             
              {inputList2.length - 1 === i && <button onClick={handleAddClick2}>Add</button>}
              <button onClick={handleAddLA}>Save</button>
             
            </div>
          </div>
        );
      })}
        </div>
      </Collapse>
      </div>


      <div>
      <Button
        onClick={() => setOpen(!open)}
        aria-controls="example-collapse-text"
        aria-expanded={open}
      >
        click
      </Button>
      <Collapse in={open}>
        <div id="example-collapse-text">
        {inputList3.map((x, i) => {
        return (
          <div className="box">
        
            <input
              name="noteName"
              placeholder="Enter First Name"
              value={x.noteName}
              onChange={e => handleInputChange3(e, i)}
            />
            <input
              className="ml10"
              name="amt"
              placeholder="Enter Last Name"
              value={x.amt}
              onChange={e => handleInputChange3(e, i)}
            />
            <div className="btn-box">
             
              {inputList3.length - 1 === i && <button onClick={handleAddClick3}>Add</button>}
              <button onClick={handleAddNR}>Save</button>
             
            </div>
          </div>
        );
      })}
        </div>
      </Collapse>
      </div>

      <div>
      <Button
        onClick={() => setOpen(!open)}
        aria-controls="example-collapse-text"
        aria-expanded={open}
      >
        click
      </Button>
      <Collapse in={open}>
        <div id="example-collapse-text">
        {inputList4.map((x, i) => {
        return (
          <div className="box">
        
            <input
              name="noteName"
              placeholder="Enter First Name"
              value={x.noteName}
              onChange={e => handleInputChange4(e, i)}
            />
            <input
              className="ml10"
              name="amt"
              placeholder="Enter Last Name"
              value={x.amt}
              onChange={e => handleInputChange4(e, i)}
            />
            <div className="btn-box">
             
              {inputList4.length - 1 === i && <button onClick={handleAddClick4}>Add</button>}
              <button onClick={handleAddSL}>Save</button>
             
            </div>
          </div>
        );
      })}
        </div>
      </Collapse>
      </div>


      <div style={{ marginTop: 20 }}>{JSON.stringify(inputList)}</div> 
      <div style={{ marginTop: 20 }}>{JSON.stringify(props.netWorth)}</div> 

      </div>
    </div>
  );
}

NetWorth.propTypes = {
  dispatch: PropTypes.func.isRequired,
};

const mapStateToProps = createStructuredSelector({
  netWorth: makeSelectNetWorth(),
});

function mapDispatchToProps(dispatch) {
  return {
    dispatch,
    addCI:(data)=>{dispatch(addCI(data))},
    addLA:(data)=>{dispatch(addLA(data))},
    addNR:(data)=>{dispatch(addNR(data))},
    addSL:(data)=>{dispatch(addSL(data))},
  };
}

const withConnect = connect(
  mapStateToProps,
  mapDispatchToProps,
);

export default compose(
  withConnect,
  memo,
)(NetWorth);

/**
 *
 * Example
 *
 */

import React, { memo,useState,useContext} from 'react';
import AccordionContext from 'react-bootstrap/AccordionContext';
import {useAccordionToggle} from 'react-bootstrap/AccordionToggle';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { Helmet } from 'react-helmet';
import { FormattedMessage } from 'react-intl';
import { createStructuredSelector } from 'reselect';
import { compose } from 'redux';
import Form from './Form'
import {addCI} from './actions';
import Accordion from 'react-bootstrap/Accordion'
import Card from 'react-bootstrap/Card'
import 'bootstrap/dist/css/bootstrap.css';
//import '../../components/AddInput/node_modules/bootstrap/dist/css/bootstrap.css';
import Calculation from 'components/Calculation/Index';
import Wrapper from 'components/UpperDiv/Wrapper';
import FormWrapper from 'components/FormWrapper/FormWrapper';
import AccordionWrapper from 'components/AccordionHeader/AccordionWrapper';
import { useInjectSaga } from 'utils/injectSaga';
import { useInjectReducer } from 'utils/injectReducer';
import makeSelectExample from './selectors';
import reducer from './reducer';
import saga from './saga';
import messages from './messages';

export function Example(props) {
  const [state3, setState3] = useState({id:"", noteName:"", amt:"" });
  const [state2, setState2] = useState({id:"", noteName:"", amt:"" });
  const [inputList, setInputList] = useState([{ id :(Math.floor(Math.random() * 99 + 100)).toString(), noteName: "", amt: "" }]);
  const [state, setState] = useState({id:"", noteName:"", amt:"" });
  const handleChange=(e,i,j,r)=>{
 
   const name= e.target.name;
   const value= e.target.value;
   
  const d= props.example.sheets[i].data[j].data.filter(l=>l.noteName===name)
  

   if(r==0){  
        setState({id:d[0].id,noteName:d[0].noteName,amt:value})
   
   }
   if(r==1){  
         setState2({id:d[0].id,noteName:d[0].noteName,amt:value})

    }
    if(r==2){  
      setState3({id:d[0].id,noteName:d[0].noteName,amt:value})

     }
  
  };

  useInjectReducer({ key: 'example', reducer });
  useInjectSaga({ key: 'example', saga });

  const handleInputChange = (e, index) => {
    console.log("index",index);
   
    const { name, value } = e.target;
    const list = [...inputList];
   
    list[index][name] = value;
    setInputList(list);
  };

  const handleRemoveClick = index => {
    const list = [...inputList];
    list.splice(index, 1);
    setInputList(list);
  };

  const handleAddClick = () => {
        
        setInputList([...inputList, 
          { id :(Math.floor(Math.random() * 99 + 100)).toString(),
            noteName: "", amt: "" }]);
      };

  const submitData = (s_d,d_d) => { 
    var s_id=s_d
    var d_id=d_d
    var newEmployee=[];
    const sheetdata=props.example.sheets.filter(sheet => sheet.id === s_id)
    const formdata=sheetdata[0].data.filter(datas => datas.id === d_id)
    if(state.amt==="" && state.noteName===""){
      const oldData={
        id:formdata[0].data[0].id,
        noteName:formdata[0].data[0].noteName,
        amt:formdata[0].data[0].amt
      }
      newEmployee.push(oldData)
    }
    else(newEmployee.push(state));
    if(state2.amt==="" && state2.noteName===""){
      const oldData={
        id:formdata[0].data[1].id,
        noteName:formdata[0].data[1].noteName,
        amt:formdata[0].data[1].amt
      }
      newEmployee.push(oldData)
    }
    else(newEmployee.push(state2));
    if(state3.amt==="" && state3.noteName===""){
      const oldData={
        id:formdata[0].data[2].id,
        noteName:formdata[0].data[2].noteName,
        amt:formdata[0].data[2].amt
      }
      newEmployee.push(oldData)
    }
    else(newEmployee.push(state3));
    //newEmployee.push(state2,state3);
    for (var i=0;i<inputList.length;i++){
      if(inputList[i].amt!==""){
      newEmployee.push(inputList[i])
      }
    }
     props.addCI(newEmployee,s_id,d_id);
     //console.log(parseInt(props.example.sheets[0].data[0].data[0].amt))
     clearData();
    
  } 

  const  clearData = () => {  
    setState({  
      
      noteName: "",  
      amt: ""  
    }); 
    setState2({  
      
      noteName: "",  
      amt: ""  
    }); 
    setState3({  
      
      noteName: "",  
      amt: ""  
    }); 

    setInputList([{
      id :(Math.floor(Math.random() * 99 + 100)).toString(),
      noteName:"",
      amt:""
    }])
    //setInputList(null)
    //console.log(props.example)
   }  


   const calculationForm=(i,j)=>{
    var sum1=0;  
    
   
      for(var k=0;k<(props.example.sheets[i].data[j].data.length);k++){
         sum1=sum1+parseInt(props.example.sheets[i].data[j].data[k].amt)
         
      }
    
        return sum1

   }
  // var sum1=0;
   const calculationAsset=()=>{
    var sum1=0;  
     var sum2=0;
    for (var b=0;b<(props.example.sheets[0].data.length);b++)
    {
      for(var k=0;k<(props.example.sheets[0].data[b].data.length);k++){
         sum1=sum1+parseInt(props.example.sheets[0].data[b].data[k].amt)
         
      }
    }
        return sum1

   }
    
   const calculationLiability=()=>{
    var sum1=0;  
    
    for (var b=0;b<(props.example.sheets[1].data.length);b++)
    {
      for(var k=0;k<(props.example.sheets[1].data[b].data.length);k++){
         sum1=sum1+parseInt(props.example.sheets[1].data[b].data[k].amt)
         
      }
    }
        return sum1

   }


   const calculationNet=()=>{
    var sum1=0;  
     var sum2=0;
    for (var b=0;b<(props.example.sheets[0].data.length);b++)
    {
      for(var k=0;k<(props.example.sheets[0].data[b].data.length);k++){
         sum1=sum1+parseInt(props.example.sheets[0].data[b].data[k].amt)
         
      }
    }

    for (var v=0;v<(props.example.sheets[1].data.length);v++)
    {
      for(var s=0;s<(props.example.sheets[1].data[v].data.length);s++){
         sum2=sum2+parseInt(props.example.sheets[1].data[v].data[s].amt)
         
      }
    }
        return (sum1-sum2)

   }



  return (
    
    <div>
     
      <h3><center>Net <em style={{fontFamily:"cursive",color:"gray"}}>worth</em></center></h3>
      <div className="leftsection"> 
      <Wrapper>
        <h6><b>Summary</b></h6>
         <Calculation  calculate={calculationAsset} fieldname="Total Assets"/>
         <Calculation  calculate={calculationLiability} fieldname="Total Liabilities"/>
         <Calculation  calculate={calculationNet} fieldname="You have a net Worth"/>
      </Wrapper>
      
      <div>
      <h4>
        Assets
      </h4>
      <FormWrapper>
     
      <Accordion defaultActiveKey="6" >
          <Card>
         
          <Accordion.Toggle as={Card.Header} style={{backgroundColor: "white",height:40}} eventKey="0">
          <b>+ Cash and Investments</b>
            </Accordion.Toggle>   
            <Accordion.Collapse eventKey="0">
              <Card.Body>
              <Form /*name="cash" name2="cash2" */
                  s_id="1" d_id="101" 
                  initstate={props.example} 
                  i={0} j={0} 
                  handleRemoveClick={ handleRemoveClick} 
                  submitData={submitData}
                    inputList={inputList} 
                    handleChange={handleChange} 
                      handleInputChange={handleInputChange} 
                      handleAddClick={handleAddClick} 
                      calculationForm={calculationForm}
                      clearData={clearData}
                        formname="Cash and Investments"
                      />
              </Card.Body>
            </Accordion.Collapse>
            
          </Card>
          </Accordion>
          
          <Accordion>
          <Card>
          
            <Accordion.Toggle as={Card.Header} style={{backgroundColor: "white" ,height:40}} eventKey="1">
            <b>+ Long-Term Assets</b>
            </Accordion.Toggle>
            <Accordion.Collapse eventKey="1">
              <Card.Body>
              <Form  s_id="1" d_id="102" formname="Long-Term Assets" clearData={clearData} initstate={props.example} calculationForm={calculationForm} i={0} j={1}   handleRemoveClick={handleRemoveClick}  submitData={submitData} inputList={inputList}  handleChange={handleChange}  handleInputChange={handleInputChange} handleAddClick={handleAddClick }/>

              </Card.Body>
            </Accordion.Collapse>
         
          </Card>
          </Accordion>
          <Accordion>
          <Card>
          
            <Accordion.Toggle as={Card.Header} style={{backgroundColor: "white",height:40}} eventKey="2">
            <b>+ Property Assets</b>
            </Accordion.Toggle>
            <Accordion.Collapse eventKey="2">
              <Card.Body>
              <Form /*name="cash" name2="cash2" */
                  s_id="1" d_id="103" 
                  initstate={props.example} 
                  i={0} j={2} 
                  handleRemoveClick={ handleRemoveClick} 
                  submitData={submitData}
                  clearData={clearData}
                    inputList={inputList} 
                    handleChange={handleChange} 
                      handleInputChange={handleInputChange} 
                      handleAddClick={handleAddClick} 
                      calculationForm={calculationForm}
                        formname="Property Assets"
                      />
              </Card.Body>
            </Accordion.Collapse>
        
          </Card>
          
          </Accordion>
          </FormWrapper>
          </div>
          <div>
          <h4>
            Liabilities
          </h4>
          <FormWrapper>
           <Accordion>
          <Card>
        
            <Accordion.Toggle as={Card.Header} style={{backgroundColor: "white",height:40}}  eventKey="3">
            <b>+ Short-Term Liabilities</b>
            </Accordion.Toggle>
            <Accordion.Collapse eventKey="3">
              <Card.Body>
              <Form /*name="cash" name2="cash2" */
                  s_id="2" d_id="201" 
                  initstate={props.example} 
                  i={1} j={0} 
                  handleRemoveClick={ handleRemoveClick} 
                  calculationForm={calculationForm}
                  submitData={submitData}
                  clearData={clearData}
                    inputList={inputList} 
                    handleChange={handleChange} 
                      handleInputChange={handleInputChange} 
                      handleAddClick={handleAddClick} 
                        formname="Short-Term Liabilities"
                      />
              </Card.Body>
            </Accordion.Collapse>
           
          </Card>
          </Accordion>
          <Accordion>
          <Card>
         
            <Accordion.Toggle as={Card.Header} style={{backgroundColor: "white",height:40}}eventKey="4">
            <b>+ Mid and Long-Term Liabilities</b>
            </Accordion.Toggle>
            <Accordion.Collapse eventKey="4">
              <Card.Body>
              <Form /*name="cash" name2="cash2" */
                  s_id="2" d_id="301" 
                  initstate={props.example} 
                  i={1} j={1} 
                  handleRemoveClick={ handleRemoveClick} 
                  submitData={submitData}
                  clearData={clearData}
                  calculationForm={calculationForm}
                    inputList={inputList} 
                    handleChange={handleChange} 
                      handleInputChange={handleInputChange} 
                      handleAddClick={handleAddClick} 
                        formname="Mid and Long-Term Liabilities"
                      />
              </Card.Body>
            </Accordion.Collapse>
           
          </Card>         
       </Accordion>
        </FormWrapper>
        </div>

       
          </div>

         
    </div>
  );
}

Example.propTypes = {
  dispatch: PropTypes.func.isRequired,
};

const mapStateToProps = createStructuredSelector({
  example: makeSelectExample(),
});

function mapDispatchToProps(dispatch) {
  return {
    dispatch,
    addCI:(data,s_id,d_id)=>{dispatch(addCI(data,s_id,d_id))},
  };
}

const withConnect = connect(
  mapStateToProps,
  mapDispatchToProps,
);

export default compose(
  withConnect,
  memo,
)(Example);







/*
 <Helmet>
     
        <meta name="description" content="Description of Example" />
      </Helmet>
      <FormattedMessage {...messages.header} />*/
/*
 *
 * Example reducer
 *
 */
import produce from 'immer';
import { DEFAULT_ACTION } from './constants';

export const initialState = {sheets:[

  
  { id :"1",categories_name: "assets", data:  
                    [
                      {id :"101", categories_name: "cash and investments",data:[ 
                                {id :"1011", noteName: "Cash",amt:"0"},
                                {id :"1012", noteName: "Chequing and Savins Account",amt:"0"},
                                {id :"1013", noteName: "Non-Registered Investments",amt:"0"},
                              ]},
                      {id :"102", categories_name: "Long-Term Assets",data:[
                        {id :"1021", noteName: "Long-Term Assets-1",amt:"0"},
                        {id :"1022", noteName: "Long-Term Assets-2",amt:"0"},
                        {id :"1023", noteName: "Others",amt:"0"}
                      ]},
                      {id :"103", categories_name: "Property Assets",data:[
                        {id :"1031", noteName: "Property Assets-1",amt:"0"},
                        {id :"1032", noteName: "Property Assets-2",amt:"0"},
                        {id :"1033", noteName: "Others",amt:"0"}
                      ]}
                    ]
                    },
                    { id :"2",categories_name: "Liabilities", data: 
                    [
                      {id :"201", categories_name: "Short-Term Liabilities",data:[
                        {id :"2011", noteName: "Short-Term Liabilities-1",amt:"0"},
                        {id :"2012", noteName: "Short-Term Liabilities-2",amt:"0"},
                        {id :"2013", noteName: "Others",amt:"0"}
                      ]},
                      {id :"301", categories_name: "Mid and Long-Term Liabilities",data:[
                        {id :"3011", noteName: "Mid and Long-Term Liabilities-1",amt:"0"},
                        {id :"3012", noteName: "Mid and Long-Term Liabilities-2",amt:"0"},
                        {id :"3013", noteName: "Others",amt:"0"} ,
                        {id :"3014", noteName: "Others2",amt:"0"} 

                      ]}
                      ]
                    }
                  ]
}
;

/* eslint-disable default-case, no-param-reassign */
const exampleReducer = (state = initialState, action) =>
  produce(state, (/* draft */) => {
    switch (action.type) {
      case DEFAULT_ACTION:
        break;

        case 'ADD_CI':
          console.log(state)
          return {    
           ...state,
           sheets:[
             ...(state.sheets.map(sheet =>
               sheet.id === action.s_id
               ? { ...sheet, data:[
                     ...(sheet.data.map(d=>
                       d.id===action.d_id
                       ?{...d,data:action.payload
                       }:d))

               ]
            }
               : sheet
             ))
           ]
         
        }
    }
    
  });

export default exampleReducer;

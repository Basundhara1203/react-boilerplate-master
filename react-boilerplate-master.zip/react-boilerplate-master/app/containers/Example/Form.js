import React, { Component } from "react";
//import './style.css'
import {Container, Col, Row ,Table} from 'react-bootstrap';
import 'bootstrap/dist/css/bootstrap.css';
//import '../../components/AddInput/node_modules/bootstrap/dist/css/bootstrap.css'
import TextInput from 'components/FixedInput2/Index';
import AddInput from 'components/AddInput/Index';
import {SubmitButton} from 'components/FormSave/index';
import {CancelButton} from 'components/FormCancel/index';
import { connect } from "react-redux";
//import { formValues } from "redux-form";
//import TextInput from './component/TextInput';
import Accordion from 'react-bootstrap/Accordion'
import Card from 'react-bootstrap/Card'
import Button from 'react-bootstrap/Button'





export default function Form(props) {

return( 
    <div>
 
<div>
<Table>
  <th >
      Total  {props.formname}
  </th>
 
  <th >
    {props.calculationForm(props.i,props.j)}
  </th>
</Table>
    {props.initstate.sheets[props.i].data[props.j].data.map((form,r) => {
return(
  
  <div>
  <TextInput form={form}  r={r} i={props.i} j={props.j} handleChange={props.handleChange}/>
  </div>
      
  
      );
      }
      )}
      </div>

   

<div id="example-collapse-text">


<Accordion  defaultActiveKey="1">
  <Card>
    <Accordion.Toggle style={{width:100}} eventKey="0">
      Add more..
    </Accordion.Toggle>
    <Accordion.Collapse eventKey="0">
      <Card.Body>
        
      {props.inputList.map((x, i) => {
   return (
     <div className="box">
                    <AddInput  field1="noteName" field2="amt" handleInputChange={props.handleInputChange} i={i}
                      handleAddClick={props.handleAddClick} handleRemoveClick= {props.handleRemoveClick}
                    />
                 </div>
                );
                }
                )
                }


            </Card.Body>
          </Accordion.Collapse>
        </Card>
      </Accordion>
    
     </div>
  <SubmitButton submitData={props.submitData} s_id={props.s_id} d_id={props.d_id}/>
    <CancelButton clearData={props.clearData}/>
  </div> 
 


  );
  }









/*props.inputList.length - 1 === i &&
props.inputList.length !== 0 &&

cash: <input onChange={(e)=>props.handleChange(e,props.i,props.j)}  name={props.name} value={props.state.amt} type="text" /> <br />  
   cash2 :  <input onChange={(e)=>props.handleChange2(e,props.i,props.j)}  name={props.name2} value={props.state2.amt} type="text" /><br /> 


    <div id="example-collapse-text">
  
       {props.inputList.map((x, i) => {
        return (
          <div className="box">
        
            <input
              name="noteName"
              placeholder="Enter First Name"
              //value={x.noteName}
              onChange={e => props.handleInputChange(e, i)}
            />
            <input
              className="ml10"
              name="amt"
              placeholder="Enter Last Name"
              //value={x.amt}
              onChange={e => props.handleInputChange(e, i)}
            />
            <div className="btn-box">
             
              { <button onClick={props.handleAddClick}>Add</button>}
              {<button
             
              onClick={() => props.handleRemoveClick(i)}>Remove</button>}
             
            </div>
          </div>
        );
      })}
        </div> 
    <button onClick={()=>props.submitData(props.s_id,props.d_id)}>ADD</button> 
  </div> 
)

 }
 












  <input
                    name="noteName"
                    placeholder="Enter First Name"
                    //value={x.noteName}
                    onChange={e => props.handleInputChange(e, i)}
                  />
                  <input
                    className="ml10"
                    name="amt"
                    placeholder="Enter Last Name"
                    //value={x.amt}
                    onChange={e => props.handleInputChange(e, i)}
                  />






     <label>
      {form.noteName}
      </label>
      <input onChange={(e)=>props.handleChange(e,props.i,props.j,r)}  name={form.noteName} defaultValue={form.amt} type="text" /> </div>

































   <div>
{props.initstate.sheets[props.i].data[props.j].data.map((form) => {
return(
 <div>
 <label>
 {form.noteName}
 </label>
 <input onChange={(e)=>props.handleChange(e,props.i,props.j)}  name={form.noteName}  type="text" /> </div>
);
}
)}
</div>

*/
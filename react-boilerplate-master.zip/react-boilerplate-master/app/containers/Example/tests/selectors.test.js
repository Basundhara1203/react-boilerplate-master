// import { selectExampleDomain } from '../selectors';

describe('selectExampleDomain', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(false);
  });
});

/*
 *
 * Example actions
 *
 */

import { DEFAULT_ACTION } from './constants';

export function defaultAction() {
  return {
    type: DEFAULT_ACTION,
  };
}

export function addCI(data,s_id,d_id) {  
  return dispatch => {  
    console.log(data)

      return dispatch({  
          type: 'ADD_CI',  
          payload: data ,
          s_id:s_id,
          d_id:d_id
      });  
  }  
}; 




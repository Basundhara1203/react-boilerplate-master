/*
 *
 * Example constants
 *
 */

export const DEFAULT_ACTION = 'app/Example/DEFAULT_ACTION';

/*
 *
 * EmpReg constants
 *
 */

export const DEFAULT_ACTION = 'app/EmpReg/DEFAULT_ACTION';

/*
 *
 * EmpReg reducer
 *
 */
import produce from 'immer';
import { DEFAULT_ACTION } from './constants';
import { reducer as formReducer } from 'redux-form';
import {combineReducers} from 'redux';
export const initialState = {};

/*
const empRegReducer = combineReducers({
  form: reduxFormReducer, // mounted under "form"
});

/* eslint-disable default-case, no-param-reassign */
export default formReducer

//export default empRegReducer;
/*
const empRegReducer = (state = initialState, action) =>
  produce(state, (/* draft ) => {
    switch (action.type) {
      case DEFAULT_ACTION:
        break;
    }
  });
  */
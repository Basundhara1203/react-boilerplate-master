// import { selectEmpRegDomain } from '../selectors';

describe('selectEmpRegDomain', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(false);
  });
});

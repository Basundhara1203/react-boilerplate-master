/**
 *
 * EmpReg
 *
 */

import React, { memo } from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { Helmet } from 'react-helmet';
import { FormattedMessage } from 'react-intl';
import { createStructuredSelector } from 'reselect';
import showResults from "./showResults";
import FieldLevelValidationForm from "./FieldLevelValidationForm";
import { compose } from 'redux';

import { Field, reduxForm } from 'redux-form'

import { useInjectSaga } from 'utils/injectSaga';
import { useInjectReducer } from 'utils/injectReducer';
import makeSelectEmpReg from './selectors';
import reducer from './reducer';
import saga from './saga';
import messages from './messages';

export function EmpReg() {
 // useInjectReducer({ key: 'empReg', reducer });
  useInjectSaga({ key: 'empReg', saga });

  return (
    <div>
      <Helmet>
        <title>EmpReg</title>
        <meta name="description" content="Description of EmpReg" />
      </Helmet>
      <FormattedMessage {...messages.header} />
      <div>
      <FieldLevelValidationForm onSubmit={showResults} />

      </div>
    </div>
  );
}

EmpReg.propTypes = {
  dispatch: PropTypes.func.isRequired,
};

const mapStateToProps = createStructuredSelector({
  empReg: makeSelectEmpReg(),
});

function mapDispatchToProps(dispatch) {
  return {
    dispatch,
  };
}

const withConnect = connect(
  mapStateToProps,
  mapDispatchToProps,
);

export default compose(
  reduxForm({
    form: 'fieldLevelValidation' // a unique identifier for this form
  }),
  withConnect,
  memo,
)(EmpReg);

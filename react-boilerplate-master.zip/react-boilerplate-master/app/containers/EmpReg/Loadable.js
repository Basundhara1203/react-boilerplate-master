/**
 *
 * Asynchronously loads the component for EmpReg
 *
 */

import loadable from 'utils/loadable';

export default loadable(() => import('./index'));

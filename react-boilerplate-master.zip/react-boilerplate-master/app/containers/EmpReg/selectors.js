import { createSelector } from 'reselect';
import { initialState } from './reducer';

/**
 * Direct selector to the empReg state domain
 */

const selectEmpRegDomain = state => state.empReg || initialState;

/**
 * Other specific selectors
 */

/**
 * Default selector used by EmpReg
 */

const makeSelectEmpReg = () =>
  createSelector(
    selectEmpRegDomain,
    substate => substate,
  );

export default makeSelectEmpReg;
export { selectEmpRegDomain };

/**
 *
 * App
 *
 * This component is the skeleton around the actual pages, and should only
 * contain code that should be seen on all pages. (e.g. navigation bar)
 */

import React from 'react';
import { Helmet } from 'react-helmet';
import styled from 'styled-components';
import { Switch, Route } from 'react-router-dom';
import Registration from 'containers/Registration/Loadable';
import EmployeeTable from 'containers/EmployeeTable/Loadable';
import Crudapplication from 'containers/Crudapplication/Loadable';
import Employee from 'containers/Employee/Loadable';
import LoginPage from 'containers/LoginPage/Loadable';
import BalancedSheet from 'containers/BalancedSheet/Loadable';
import NetWorth from 'containers/NetWorth/Loadable';
import Example from 'containers/Example/Loadable';
import NetBalance from 'containers/NetBalance/Loadable';
import Example2 from 'containers/Example2/Loadable';
import Net from 'containers/Net/Loadable';
import Worth from 'containers/Worth/Loadable';
import {Choice} from 'containers/LoginPage/Choice';
import EmpReg from 'containers/EmpReg/Loadable';

import HomePage from 'containers/HomePage/Loadable';
import FeaturePage from 'containers/FeaturePage/Loadable';
import NotFoundPage from 'containers/NotFoundPage/Loadable';
import Header from 'components/Header';
import Footer from 'components/Footer';
import { ProtectedRoute } from "containers/LoginPage/ProtectedRoute";

import GlobalStyle from '../../global-styles';
//import { NetBalance } from '../NetBalance';

const AppWrapper = styled.div`
  max-width: calc(768px + 16px * 2);
  margin: 0 auto;
  display: flex;
  min-height: 100%;
  padding: 0 16px;
  flex-direction: column;
`;

export default function App() {
  return (
    <AppWrapper>
      <Helmet
        titleTemplate="%s - React.js Boilerplate"
        defaultTitle="React.js Boilerplate"
      >
        <meta name="description" content="A React.js Boilerplate application" />
      </Helmet>
      <Header />
      <Switch>
        <Route exact path="/" component={HomePage} />
        <Route path="/features" component={FeaturePage} />
        <Route path="/Registration" component={Registration} />
        <Route path="/EmployeeTable" component={EmployeeTable} />
        
        <Route path="/Crudapplication" component={Crudapplication} />
        <Route path="/LoginPage" component={LoginPage} />
        <Route path="/BalancedSheet" component={BalancedSheet } />
        <Route path="/NetWorth" component={NetWorth} />
        <Route path="/Example" component={Example} />
        <Route path="/Example2" component={Example2} />
        <Route path="/NetBalance" component={NetBalance} />
        <Route path="/Net" component={Net} />
        <Route path="/EmpReg" component={EmpReg} />
        <ProtectedRoute path="/Worth" component={Worth} />
        <ProtectedRoute path="/Choice" component={Choice} />
        <ProtectedRoute exact path="/Employees" component={Employee} />
        <Route path="" component={NotFoundPage} />
      </Switch>
      <Footer />
      <GlobalStyle />
    </AppWrapper>
  );
}

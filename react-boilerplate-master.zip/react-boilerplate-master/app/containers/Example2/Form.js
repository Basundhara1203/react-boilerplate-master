import React, { Component } from "react";
//import './style.css'
import {Container, Col, Row } from 'react-bootstrap';
import 'bootstrap/dist/css/bootstrap.css';
//import '../../components/AddInput/node_modules/bootstrap/dist/css/bootstrap.css'
import TextInput from 'components/TextInput/Index';
import { connect } from "react-redux";
//import { formValues } from "redux-form";
//import TextInput from './component/TextInput';





export default function Form(props) {

return(
    <div>
    cash: <input onChange={(e)=>props.handleChange(e,props.i,props.j)}  name={props.name} value={props.state.amt} type="text" /> <br />  
   cash2 :  <input onChange={(e)=>props.handleChange2(e,props.i,props.j)}  name={props.name2} value={props.state2.amt} type="text" /><br /> 
   <div id="example-collapse-text">
       {props.inputList.map((x, i) => {
        return (
          <div className="box">
        
            <input
              name="noteName"
              placeholder="Enter First Name"
              value={x.noteName}
              onChange={e => props.handleInputChange(e, i)}
            />
            <input
              className="ml10"
              name="amt"
              placeholder="Enter Last Name"
              value={x.amt}
              onChange={e => props.handleInputChange(e, i)}
            />
            <div className="btn-box">
             
              {props.inputList.length - 1 === i && <button onClick={props.handleAddClick}>Add</button>}
          
             
            </div>
          </div>
        );
      })}
        </div> 
    <button onClick={props.submitData}>ADD</button> 
  </div> 
)

 }


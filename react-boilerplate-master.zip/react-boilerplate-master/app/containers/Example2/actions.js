/*
 *
 * Example2 actions
 *
 */

import { DEFAULT_ACTION } from './constants';

export function defaultAction() {
  return {
    type: DEFAULT_ACTION,
  };
}
export function addCI(data) {  
  return dispatch => {  
    console.log(data)

      return dispatch({  
          type: 'ADD_CI',  
          payload: data ,
        
      });  
  }  
}; 

export function addLA(data) {  
  return dispatch => {  
    console.log(data)

      return dispatch({  
          type: 'ADD_CI',  
          payload: data ,
        
      });  
  }  
}; 

/*
 *
 * Example2 constants
 *
 */

export const DEFAULT_ACTION = 'app/Example2/DEFAULT_ACTION';

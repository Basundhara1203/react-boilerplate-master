/*
 *
 * Example2 reducer
 *
 */
import produce from 'immer';
import { DEFAULT_ACTION } from './constants';
import { reducer as reduxFormReducer } from 'redux-form';
import {combineReducers} from 'redux';

export const initialState = {

}
;
/*
const example2Reducer = combineReducers({
  form: reduxFormReducer, // mounted under "form"
});*/
/* eslint-disable default-case, no-param-reassign */

const example2Reducer = (state = initialState, action) =>
  produce(state, (/* draft */) => {
    switch (action.type) {
      case DEFAULT_ACTION:

        break;

        /*case 'ADD_CI':
          return {    
           ...state,
           sheets:[
             ...(state.sheets.map(sheet =>
               sheet.id === "1"
               ? { ...sheet, data:[
                     ...(sheet.data.map(d=>
                       d.id==="101"
                       ?{...d,data:action.payload
                       }:d))

               ]
            }
               : sheet
             ))
           ]
         
        }*/
   }
    
  });

export default example2Reducer;


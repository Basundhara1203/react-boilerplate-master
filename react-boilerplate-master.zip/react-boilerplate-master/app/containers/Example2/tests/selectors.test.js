// import { selectExample2Domain } from '../selectors';

describe('selectExample2Domain', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(false);
  });
});

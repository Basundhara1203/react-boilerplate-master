import axios from "axios";


export default function request2() {
    var data="";
   const urlresponse= axios.get("http://dummy.restapiexample.com/api/v1/employees")
         .then(urlresponse=>{
             data=urlresponse
         })
      console.log("ok",data);
      return (data)
  }

